<?php
/**
 * Template Name: Google Login
 * 
 * Processa a autenticação via Google OAuth 2.0
 */

//define('GOOGLE_CLIENT_ID', '669513502452-7fgdho1pltk5vg1hnb8s06adn1i0fj6o.apps.googleusercontent.com');
//define('GOOGLE_CLIENT_SECRET', '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');

define('GOOGLE_CLIENT_ID', '349747948304-85pa1fc8pj4fc7fvts6sp24shkh72o9k.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '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');

define('GOOGLE_REDIRECT_URI', home_url('/googlelogin'));
define('GOOGLE_TOKEN_URL', 'https://oauth2.googleapis.com/token');
define('GOOGLE_USERINFO_URL', 'https://www.googleapis.com/oauth2/v2/userinfo');

// Iniciar fluxo de autenticação
$redirect_params = [
    'client_id' => GOOGLE_CLIENT_ID,
    'redirect_uri' => GOOGLE_REDIRECT_URI,
    'response_type' => 'code',
    'scope' => 'email profile',
    'access_type' => 'online',
    'prompt' => 'select_account'
];

// Se não tem código, redireciona para auth do Google
if (!isset($_GET['code'])) {
    $auth_url = 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query($redirect_params);
    wp_redirect($auth_url);
    exit;
}

// Processar o retorno com o código de autorização
try {
    // Trocar código por token de acesso
    $token_params = [
        'code' => $_GET['code'],
        'client_id' => GOOGLE_CLIENT_ID,
        'client_secret' => GOOGLE_CLIENT_SECRET,
        'redirect_uri' => GOOGLE_REDIRECT_URI,
        'grant_type' => 'authorization_code'
    ];

    $response = wp_remote_post(GOOGLE_TOKEN_URL, [
        'body' => $token_params
    ]);

    if (is_wp_error($response)) {
        throw new Exception('Falha na comunicação com Google: ' . $response->get_error_message());
    }

    $token_data = json_decode($response['body'], true);
    if (!isset($token_data['access_token'])) {
        throw new Exception('Token de acesso não recebido do Google');
    }

    // Obter informações do usuário
    $userinfo_response = wp_remote_get(GOOGLE_USERINFO_URL, [
        'headers' => [
            'Authorization' => 'Bearer ' . $token_data['access_token']
        ]
    ]);

    if (is_wp_error($userinfo_response)) {
        throw new Exception('Falha ao obter informações do usuário: ' . $userinfo_response->get_error_message());
    }

    $userinfo = json_decode($userinfo_response['body'], true);
    if (!isset($userinfo['email'])) {
        throw new Exception('E-mail não disponível no perfil do Google');
    }

    $email = strtolower($userinfo['email']);

    // Verificar domínio permitido
    $dominio = substr(strrchr($email, "@"), 1);
    $emails_excecao = get_option('portal_input_3', []);

    if ($dominio !== 'unicamp.br' && $dominio !== 'dac.unicamp.br' && !in_array($email, (array) $emails_excecao)) {
        wp_die('Acesso negado.<br>Somente e-mails @unicamp.br, @dac.unicamp.br ou convidados podem acessar o sistema.');
    }

    // Processar autenticação no WordPress    
    $username = preg_replace('/@.*/', '', $email); // Remove domínio do email para username
    $first_name = $userinfo['given_name'] ?? '';
    $last_name = $userinfo['family_name'] ?? '';


    // Permitir login local apenas para o admin (similar ao LDAP)
    if ($username === 'admin') {
        wp_die('Login de admin não permitido via Google');
    }

    $user = get_user_by('email', $email);

    if (!$user) {
        // Criar novo usuário
        $user_id = wp_create_user($username, wp_generate_password(), $email);

        if (is_wp_error($user_id)) {
            throw new Exception('Falha ao criar usuário: ' . $user_id->get_error_message());
        }

        // Atualizar informações do usuário
        wp_update_user([
            'ID' => $user_id,
            'first_name' => $first_name,
            'last_name' => $last_name,
            'role' => papel_usuario($email) // Reutilizando sua função existente
        ]);

        $user = get_user_by('id', $user_id);

        // Se houver imagem no perfil do Google, importa como avatar
        if (!empty($userinfo['picture'])) {
            $avatar_id = importar_imagem_para_midia($userinfo['picture'], $user->ID);
            if ($avatar_id) {
                update_user_meta($user->ID, 'wp_user_avatar', $avatar_id);
            }
        }
        
    }

    // Atualizar metadados (similar ao LDAP)
    $tipos_registrados = ['congrega', 'ci', 'dsc', 'dsi', 'dtc', 'cdi'];

    // Primeiro revoga tudo
    update_user_meta($user->ID, 'membro', null);
    update_user_meta($user->ID, 'membro_arquivo_privado', null);
    update_user_meta($user->ID, 'membro_post_privado', null);

    // Depois reclassifica
    if (papel_usuario($email) == 'editor' || papel_usuario($email) == 'administrator') {
        update_user_meta($user->ID, 'membro', $tipos_registrados);
        update_user_meta($user->ID, 'membro_arquivo_privado', $tipos_registrados);
        update_user_meta($user->ID, 'membro_post_privado', $tipos_registrados);
    } else {
        $grupos = retorna_membro($email); // verifica na intranet

        if (!in_array('congrega', $grupos)) {
            $grupos[] = 'congrega';
        }

        if (!in_array('ci', $grupos)) {
            $grupos[] = 'ci';
        }

        if (count($grupos) === 2 && !array_diff($grupos, ['congrega', 'ci']) && !array_diff(['ci', 'congrega'], $grupos)) {
            $grupos = array_merge($grupos, retorna_membro_siteic($email));
        }

        update_user_meta($user->ID, 'membro', $grupos);
        update_user_meta($user->ID, 'membro_arquivo_privado', retorna_membro($email));
    }

    // Autenticar o usuário
    wp_set_current_user($user->ID);
    wp_set_auth_cookie($user->ID);
    do_action('wp_login', $user->user_login, $user);


    // REDIRECIONAMENTO
    if (get_user_meta($user->ID, 'aceite', true)) { //verifica se user aceitou 
        $redirect_to = $_SESSION['ldap_login_redirect'];
    } else {
        $redirect_to = home_url('/perfil');
    }

    error_log('Redirecionamento page-googlelogin.php ==> ' . $redirect_to);

    wp_redirect($redirect_to);
    exit;


} catch (Exception $e) {
    wp_die('Erro no login via Google: ' . $e->getMessage() . '<br><a href="' . home_url() . '">Voltar</a>');
}
