  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="credits">
      <a target="_blank" href="https://ic.unicamp.br/">Instituto de Computação</a>
    </div>
  </footer><!-- End Footer -->

<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<?php wp_footer(); ?>

<script src="<?php echo SITEPATH; ?>assets/js/main.js"></script>

</body>

</html>