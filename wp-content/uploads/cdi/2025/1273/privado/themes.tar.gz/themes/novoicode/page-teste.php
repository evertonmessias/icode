<?php

/*

// segurança básica — rode apenas se for admin logado
if (!current_user_can('administrator')) {
    wp_die('Acesso negado.');
}

// Conecta ao banco usando as credenciais do WP
global $wpdb;

// Caminhos antigo e novo
$antigo = '/var/www/html/icode2';
$novo   = '/var/www/icode2';

// Mostra o que será feito
echo "<h3>Atualizando caminhos na tabela wp_pdf_index...</h3>";

// Executa a atualização
$query = $wpdb->prepare("
    UPDATE wp_pdf_index 
    SET arquivo = REPLACE(arquivo, %s, %s)
    WHERE arquivo LIKE %s
", $antigo, $novo, $wpdb->esc_like($antigo) . '%');

$result = $wpdb->query($query);

// Mostra o resultado
if ($result !== false) {
    echo "<p><strong>$result</strong> registros atualizados com sucesso.</p>";
} else {
    echo "<p>Erro ao atualizar os registros.</p>";
}

// (Opcional) Mostra alguns exemplos após a atualização
$exemplos = $wpdb->get_results("SELECT id, arquivo FROM wp_pdf_index LIMIT 5");
if ($exemplos) {
    echo "<h4>Exemplos após atualização:</h4><ul>";
    foreach ($exemplos as $ex) {
        echo "<li>{$ex->id}: {$ex->arquivo}</li>";
    }
    echo "</ul>";
}
*/    
?>
