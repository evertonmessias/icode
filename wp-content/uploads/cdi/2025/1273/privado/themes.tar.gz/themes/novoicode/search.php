<?php
// Arquivo: /wp-content/themes/novoicode/search.php
get_header();
?>

<?php if (get_user_meta(wp_get_current_user()->ID, 'aceite', true) == false)
   echo '<script>window.location.href = "/perfil";</script>'; ?>

<?php
$s = get_search_query();
if (url_active()[1] == 'congrega' || url_active()[1] == 'ci' || url_active()[1] == 'dsc' || url_active()[1] == 'dsi' || url_active()[1] == 'dtc' || url_active()[1] == 'cdi') {
   $tipo = url_active()[1]; // segurança
   $title = "Busca: ";
   $subtitle = $tipo;
} else {
   $tipo = get_user_meta(wp_get_current_user()->ID, 'membro', true);
   $title = "Busca Avançada: ";
   $subtitle = implode(", ",$tipo);
}

// Função para criar excerpt inteligente com contexto da busca
function smart_search_excerpt($content, $search_term, $chars_before_after = 200) {
   // Remove tags HTML e limpa o conteúdo
   $clean_content = wp_strip_all_tags($content);
   
   // Encontra a primeira ocorrência do termo de busca (case insensitive)
   $position = stripos($clean_content, $search_term);
   
   if ($position === false) {
       // Se não encontrar, retorna um excerpt normal
       return wp_trim_words($clean_content, 55);
   }
   
   // Calcula a posição inicial e final para o excerpt
   $start = max(0, $position - $chars_before_after);
   $end = $position + strlen($search_term) + $chars_before_after;
   
   // Obtém o trecho do conteúdo
   $excerpt = substr($clean_content, $start, $end - $start);
   
   // Adiciona "..." no início se não for o começo do texto
   if ($start > 0) {
       $excerpt = '... ' . $excerpt;
   }
   
   // Adiciona "..." no final se não for o fim do texto
   if ($end < strlen($clean_content)) {
       $excerpt = $excerpt . ' ...';
   }
   
   // Destaca o termo de busca em negrito
   $excerpt = preg_replace("/(" . preg_quote($search_term) . ")/i", '<strong>$1</strong>', $excerpt);
   
   return $excerpt;
}
?>


<main id="main" class="main">

   <!-- ======= Page Title & Breadcrumbs ======= -->
   <div class="pagetitle d-flex justify-content-between align-items-center">
      <div>
         <h1>
            <?php echo "<h2 class='page-title'>" . $title . "&ensp;<u>" . get_query_var('s') . "</u></h2>"; ?>
         </h1>         
      </div>
      <div class="btn-editors">
         <a class="btn btn-light" href="/"><i class="bi bi-skip-backward-fill"></i>&ensp;Voltar</a>&emsp;
      </div>
   </div><!-- End Page Title & Breadcrumbs -->

   <section class="section icode-search">
      <div class="row">
         <div class="col-lg-12">
            <div class="card">
               <div class="card-body">
                  
                  <!-- Navegação por Abas -->
                  <ul class="nav nav-tabs" id="searchTabs" role="tablist">
                     <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="posts-tab" data-bs-toggle="tab" 
                                data-bs-target="#posts-tab-pane" type="button" role="tab" 
                                aria-controls="posts-tab-pane" aria-selected="true">
                           <i class="bi bi-file-earmark-text me-2"></i>Posts
                           <span class="badge bg-primary ms-2" id="posts-count">0</span>
                        </button>
                     </li>
                     <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pdfs-tab" data-bs-toggle="tab" 
                                data-bs-target="#pdfs-tab-pane" type="button" role="tab" 
                                aria-controls="pdfs-tab-pane" aria-selected="false">
                           <i class="bi bi-file-pdf me-2"></i>PDFs
                           <span class="badge bg-primary ms-2" id="pdfs-count">0</span>
                        </button>
                     </li>
                  </ul>
                  
                  <!-- Conteúdo das Abas -->
                  <div class="tab-content" id="searchTabContent">

                     <!-- Aba de Posts -->
                     <div class="tab-pane fade show active" id="posts-tab-pane" role="tabpanel" 
                          aria-labelledby="posts-tab" tabindex="0">
                        <br>
                        <h4>Resultados em Posts</h4>
                        <p class="text-muted">Encontrados em: <?php echo $subtitle ?></p>
                        
                        <?php
                        $args = array(
                           's' => $s,
                           'post_type' => $tipo,
                           'posts_per_page' => -1,
                           'orderby' => 'date',
                           'order' => 'DESC'
                        );

                        $query = new WP_Query($args);
                        $user_id = wp_get_current_user()->ID;
                        $user_privado = get_user_meta($user_id, 'privado', true);
                        $posts_count = 0;

                        if ($query->have_posts()) {
                           ?>
                           <table class="table table-striped table-hover tcategory">
                              <thead>
                                 <tr>
                                    <th>Título</th>                                    
                                    <th>Data</th>
                                 </tr>
                              </thead>
                              <tbody>
                                 <?php
                                 while ($query->have_posts()) {
                                    $query->the_post();
                                    $post_id = get_the_ID();
                                    $post_privado = get_post_meta($post_id, $tipo . '_privado', true);

                                    if ($post_privado && !$user_privado) {
                                       continue;
                                    }

                                    $posts_count++;
                                    ?>
                                    <tr>
                                       <td class="td1">
                                          <h5><a href="<?php the_permalink(); ?>">
                                             <i class="bi bi-file-earmark-text"></i>&ensp;
                                             <?php the_title(); ?>
                                          </a></h5>
                                          <small><?php 
                                             $content = get_the_content();
                                             echo smart_search_excerpt($content, $s, 200);
                                          ?></small><br>
                                       </td>
                                       <td class="td2" data-order="<?php echo get_the_date('Y-m-d H:i:s'); ?>">
                                          <i class="bi bi-calendar-event"></i>&emsp;<?php echo get_the_date('d/m/Y, H:i'); ?> h
                                       </td>
                                    </tr>
                                 <?php } ?>
                              </tbody>
                           </table>
                           <?php
                        } else {
                           ?>
                           <div class="text-center py-4">
                              <i class="bi bi-search display-1 text-muted"></i>
                              <h5 class="text-muted mt-3">Nenhum post encontrado</h5>
                              <p class="text-muted">Tente ajustar os termos da sua busca</p>
                           </div>
                           <?php
                        }
                        wp_reset_postdata();
                        ?>
                        <script>
                           document.getElementById('posts-count').textContent = '<?php echo $posts_count; ?>';
                        </script>
                     </div>

                     <!-- Aba de PDFs -->
                     <div class="tab-pane fade" id="pdfs-tab-pane" role="tabpanel" 
                          aria-labelledby="pdfs-tab" tabindex="0">
                        <br>
                        <h4>Resultados em PDFs</h4>
                        <p class="text-muted">Encontrados em: <?php echo $subtitle ?></p>
                        
                        <?php
                        global $wpdb;
                        $tabela = $wpdb->prefix . 'pdf_index';
                        $pdfs_count = 0;

                        if (is_array($tipo)) {
                           $placeholders = implode(',', array_fill(0, count($tipo), '%s'));
                           $query_pdf = $wpdb->prepare("
                              SELECT * FROM $tabela 
                              WHERE texto LIKE %s AND tipo IN ($placeholders)
                              ORDER BY ano DESC
                           ", '%' . $wpdb->esc_like($s) . '%', ...$tipo);
                        } else {
                           $query_pdf = $wpdb->prepare("
                              SELECT * FROM $tabela 
                              WHERE texto LIKE %s AND tipo = %s
                              ORDER BY ano DESC
                           ", '%' . $wpdb->esc_like($s) . '%', $tipo);
                        }

                        $resultados_pdf = $wpdb->get_results($query_pdf);

                        if ($resultados_pdf) {
                           ?>
                           <table class="table table-striped table-hover tcategory">
                              <thead>
                                 <tr>                                    
                                    <th>Arquivo</th>
                                    <th>Ano</th>                                    
                                 </tr>
                              </thead>
                              <tbody>
                                 <?php
                                 foreach ($resultados_pdf as $r) {
                                    $post_privado = get_post_meta($r->id_post, $r->tipo . '_privado', true);
                                    $arquivo_privado = strpos($r->arquivo, '/privado') !== false;

                                    if (($post_privado || $arquivo_privado) && !$user_privado) {
                                       continue;
                                    }

                                    $pdfs_count++;
                                    $url_site = site_url();
                                    $url = $url_site . str_replace(ABSPATH, '/', $r->arquivo);
                                    $arquivo_nome = basename($r->arquivo);
                                    ?>
                                    <tr>                                       
                                       <td class="td1">
                                          <h5>
                                          <a href="<?php echo $url; ?>" target="_blank">
                                             <i class="bi bi-file-pdf"></i>&ensp;<?php echo $arquivo_nome; ?>
                                          </a>
                                          </h5>
                                          <small><?php echo smart_search_excerpt($r->texto, $s, 200); ?></small><br>
                                       </td>
                                       <td class="td2" data-order="<?php echo esc_attr($r->ano); ?>">
                                          <a href="<?php echo get_permalink($r->id_post); ?>">
                                             <i class="bi bi-calendar3"></i>&ensp;<?php echo $r->ano; ?>
                                          </a>
                                       </td>                       
                                    </tr>
                                 <?php } ?>
                              </tbody>
                           </table>                           
                           <?php
                        } else {
                           ?>
                           <div class="text-center py-4">
                              <i class="bi bi-file-pdf display-1 text-muted"></i>
                              <h5 class="text-muted mt-3">Nenhum PDF encontrado</h5>
                              <p class="text-muted">Tente ajustar os termos da sua busca</p>
                           </div>
                           <?php
                        }
                        ?>
                        <script>
                           document.getElementById('pdfs-count').textContent = '<?php echo $pdfs_count; ?>';
                        </script>
                     </div>

                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>

</main><!-- End #main -->

<script>
   jQuery(document).ready(function ($) {
      var dataConfig = {
         order: [[1, 'desc']], // Ordenar pela coluna de Data/Ano (índice 1)
         columnDefs: [
            {
               targets: 1, // Coluna de data/ano (índice 1)
               type: 'date', // Tipo de ordenação para datas
               render: function (data, type, row) {
                  if (type === 'display') {
                     return data;
                  }
                  return $(data).data('order') || data;
               }
            }
         ],
         dom: '<"top"lf>rt<"bottom"ip><"clear">',
         buttons: [],
         pageLength: 25,
         lengthMenu: [[25, 50, 75, 100, -1], [25, 50, 75, 100, "Todos"]],
         language: {
            emptyTable: "Nenhum conteúdo disponível",
            info: "Mostrando _START_ a _END_ de _TOTAL_ registros",
            infoEmpty: "Mostrando 0 a 0 de 0 registros",
            infoFiltered: "(filtrado de _MAX_ registros no total)",
            lengthMenu: "Mostrar _MENU_ registros por página",
            loadingRecords: "Carregando...",
            processing: "Processando...",
            search: "Pesquisar:",
            zeroRecords: "Nenhum registro encontrado",
            paginate: {
               first: "Primeiro",
               last: "Último",
               next: "Próximo",
               previous: "Anterior"
            }
         },
         // Garantir que a paginação funcione
         paging: true,
         searching: true,
         info: true,
         autoWidth: false,
         responsive: true
      };

      // Inicializar DataTable para cada aba
      function initDataTables() {
         $('.tcategory').each(function() {
            if (!$.fn.DataTable.isDataTable(this)) {
               $(this).DataTable(dataConfig);
            }
         });
      }

      // Inicializar DataTables quando a página carregar
      initDataTables();

      // Re-inicializar DataTables quando mudar de aba
      $('#searchTabs button').on('click', function () {
         setTimeout(function() {
            initDataTables();
         }, 100);
      });

      // Ajustar layout quando a janela for redimensionada
      $(window).on('resize', function() {
         $('.tcategory').DataTable().columns.adjust().responsive.recalc();
      });
   });
</script>

<?php get_footer(); ?>