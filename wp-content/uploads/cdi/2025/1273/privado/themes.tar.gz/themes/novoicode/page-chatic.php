<?php
// Arquivo: wp-content/themes/novoicode/page-chatic.php

header('Content-Type: application/json');

// Verifica se a requisição é POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método não permitido']);
    exit;
}

// Lê e decodifica o corpo da requisição
$input = json_decode(file_get_contents('php://input'), true);

// Verifica se houve erro na decodificação JSON
if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400);
    echo json_encode(['error' => 'JSON inválido']);
    exit;
}

// Verifica se os parâmetros necessários foram enviados
if (!isset($input['model']) || !isset($input['messages']) || !is_array($input['messages']) || empty($input['messages'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Parâmetros ausentes ou inválidos']);
    exit;
}

$last_message = end($input['messages']);
if (!isset($last_message['content'])) {
    http_response_code(400);
    echo json_encode(['error' => 'A última mensagem não possui o campo "content"']);
    exit;
}

$pergunta = sanitize_text_field($last_message['content']);
$contexto = "Você é um assistente virtual do Instituto de Computação (IC) da UNICAMP, com acesso a conteúdos internos em forma de posts e documentos indexados (como atas, pautas, deliberações etc).";
$out_of_context_response = "Essa pergunta não faz parte do contexto do Instituto de Computação.";

global $wpdb;
$max_content_length = 2000;

// Busca nos posts do WordPress
$post_results = get_posts([
    'post_type' => ['congrega', 'ci'],
    'posts_per_page' => 5,
    's' => $pergunta,
    'date_query' => null
]);

$post_content = '';
$post_fontes = [];
foreach ($post_results as $post) {
    $post_content .= "\n### 📌 {$post->post_title}\n";
    $post_content .= "> " . strip_tags(mb_substr($post->post_content, 0, 300)) . "...\n";
    $post_fontes[] = [
        'tipo' => 'post',
        'titulo' => $post->post_title,
        'url' => get_permalink($post->ID)
    ];
    if (strlen($post_content) > $max_content_length / 2) break;
}

// Busca na tabela de PDFs
$pdf_rows = $wpdb->get_results($wpdb->prepare(
    "SELECT id, arquivo, url, texto FROM {$wpdb->prefix}pdf_index WHERE texto LIKE %s LIMIT 3",
    '%' . $wpdb->esc_like($pergunta) . '%'
));

$pdf_content = '';
$pdf_fontes = [];
foreach ($pdf_rows as $row) {
    $nome_arquivo = basename($row->arquivo);
    $pdf_content .= "\n### 📄 {$nome_arquivo}\n";
    $pdf_content .= "> " . mb_substr($row->texto, 0, 300) . "...\n";

    $fonte_pdf = [
        'tipo' => 'pdf',
        'nome' => $nome_arquivo,
        'url' => $row->url
    ];

    $pdf_fontes[] = $fonte_pdf;
    if (strlen($pdf_content) > $max_content_length / 2) break;
}

// Formata o contexto de forma mais organizada
$contexto_completo = "## Contexto Institucional\n\n" . $contexto;

if (!empty($post_content) || !empty($pdf_content)) {
    $contexto_completo .= "\n\n## Conteúdo Relevante Encontrado\n";
    
    if (!empty($post_content)) {
        $contexto_completo .= "\n### Posts Relacionados\n" . $post_content;
    }
    
    if (!empty($pdf_content)) {
        $contexto_completo .= "\n### Documentos Relacionados\n" . $pdf_content;
    }
    
    $contexto_completo .= "\n\nPor favor, forneça uma resposta detalhada com base nestes materiais.";
} else {
    $contexto_completo .= "\n\nNenhum conteúdo específico encontrado nos sistemas internos sobre este tópico.";
}

if (strlen($contexto_completo) > $max_content_length) {
    $contexto_completo = mb_substr($contexto_completo, 0, $max_content_length) . "...";
}

// Adiciona o contexto à mensagem do usuário para a IA externa
$messages_to_send = [
    [
        'role' => 'system',
        'content' => $contexto_completo . "\n\nResponda de forma clara e organizada em Markdown, considerando a estrutura do IC. Use:\n- **negrito** para ênfase\n- Listas quando apropriado\n- Títulos (##, ###) para seções\n- > para citações\n\nSe a pergunta não estiver relacionada ao contexto, responda educadamente indicando que não possui informações e sugira contatar a secretaria."
    ],
    $last_message
];

$payload = [
    'model' => $input['model'],
    'messages' => $messages_to_send,
    'temperature' => 0.7
];

// Configura e executa o cURL (mesmo código anterior)
$ch = curl_init('https://llmapi.ic.unicamp.br/api/chat/completions');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: Bearer sk-6f42b2fb3ef745bcb834f3cdb07d1cc6'
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);

$response = curl_exec($ch);

if (curl_errno($ch)) {
    http_response_code(500);
    echo json_encode(['error' => 'Erro na requisição cURL: ' . curl_error($ch)]);
    curl_close($ch);
    exit;
}

$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// Verifica se a resposta é um JSON válido
$response_data = json_decode($response, true);
if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(500);
    echo json_encode(['error' => 'Resposta inválida da API']);
    exit;
}

// Remove a adição das fontes no conteúdo da resposta (mantém apenas no campo fontes)
if (isset($response_data['choices'][0]['message']['content'])) {
    $response_data['choices'][0]['message']['content'] = $response_data['choices'][0]['message']['content'];
}

// Adiciona as fontes na resposta (em formato bruto para o frontend)
$response_data['fontes'] = [
    'posts' => $post_fontes,
    'pdfs' => $pdf_fontes
];

// Retorna o resultado
http_response_code($http_code);
echo json_encode($response_data);
?>
