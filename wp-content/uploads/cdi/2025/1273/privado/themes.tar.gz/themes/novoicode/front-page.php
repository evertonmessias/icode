<?php
get_header();
?>

<?php if (get_user_meta(wp_get_current_user()->ID, 'aceite', true) == false)
	echo '<script>window.location.href = "/perfil";</script>'; ?>

<?php
$membro_arquivo_privado = get_user_meta(wp_get_current_user()->ID, 'membro_arquivo_privado', true);
if (is_array($membro_arquivo_privado) && in_array("congrega", $membro_arquivo_privado)) {
	$user_membro_arquivo_privado = true;
} else {
	$user_membro_arquivo_privado = false;
}
?>

<main id="main" class="main">

	<!-- React  -->
	<script src="<?php echo SITEPATH; ?>assets/js/react.js"></script>
	<script src="<?php echo SITEPATH; ?>assets/js/react-dom.js"></script>
	<script src="<?php echo SITEPATH; ?>assets/js/react-markdown.js"></script>

	<section class="section front-search">
		<div class="row">
			<div class="col-lg-12">
				<div class="card main-card-container">
					<div class="card-body">
						<!-- Navegação por Abas -->
						<ul class="nav nav-tabs" id="myTab" role="tablist">

							<li class="nav-item" role="presentation">
								<button class="nav-link active" id="search-tab" data-bs-toggle="tab"
									data-bs-target="#search-tab-pane" type="button" role="tab"
									aria-controls="search-tab-pane" aria-selected="false">
									<i class="bi bi-search me-2"></i>Busca Avançada
								</button>
							</li>

							<li class="nav-item" role="presentation">
								<button class="nav-link" id="chat-tab" data-bs-toggle="tab"
									data-bs-target="#chat-tab-pane" type="button" role="tab"
									aria-controls="chat-tab-pane" aria-selected="true">
									<i class="bi bi-robot me-2"></i>IA do ICODE
								</button>
							</li>

						</ul>

						<!-- Conteúdo das Abas -->
						<div class="tab-content" id="myTabContent">

							<!-- Aba de Busca Avançada -->
							<div class="tab-pane fade show active" id="search-tab-pane" role="tabpanel"
								aria-labelledby="search-tab" tabindex="0">
								<div class="row justify-content-center">
									<div class="col-lg-5 search-body">
										<div class="text-center mb-5"><br>
											<h4 class="mb-4">Busca Avançada no <span class="text-primary">ICODE</span>
											</h4>
											<p class="text-muted">Encontre rapidamente o conteúdo que você precisa
												em nossa base de dados</p>
										</div>

										<form class="search-form d-flex align-items-center mb-4" method="get"
											action="/">
											<input type="text" required name="s" id="search"
												placeholder="Digite sua pesquisa..." title="Pesquisar"
												value="<?php the_search_query(); ?>" class="flex-grow-1" />
											<button type="submit" title="Pesquisar" class="flex-shrink-0">
												<i class="bi bi-search"></i>
											</button>
										</form>
										<div class="text-center">
											<small class="text-muted">
												<i class="bi bi-info-circle me-1"></i>
												Busque por documentos, PDFs e conteúdos específicos
											</small>
										</div>
									</div>
								</div>
								<br>
								<br>
								<hr>

								<div class="latest-publications">

									<div class="d-flex justify-content-between align-items-center mb-4">
										<h5 class="card-title mb-0">Últimas Publicações</h5>
										<div>
											<button class="btn btn-outline-primary btn-sm me-2 carousel-prev"
												id="carouselPrev">
												<i class="bi bi-chevron-left"></i>
											</button>
											<button class="btn btn-outline-primary btn-sm carousel-next"
												id="carouselNext">
												<i class="bi bi-chevron-right"></i>
											</button>
										</div>
									</div>

									<div id="publicationsCarousel" class="carousel slide" data-bs-ride="carousel"
										data-bs-interval="4000">
										<div class="carousel-inner">
											<?php
											$post_types = ['congrega', 'ci', 'dsc', 'dsi', 'dtc', 'cdi'];
											$post_icon = ['congrega' => "bi-people-fill", 'ci' => "bi-person-lines-fill", 'dsc' => "bi-person-vcard", 'dsi' => "bi-person-vcard", 'dtc' => "bi-person-vcard", 'cdi' => "bi-person-video"];
											$posts_data = [];

											// Coleta todos os posts
											foreach ($post_types as $post_type):
												$args = [
													'post_type' => $post_type,
													'posts_per_page' => 1,
													'post_status' => 'publish',
												];
												$query = new WP_Query($args);
												if ($query->have_posts()):
													while ($query->have_posts()):
														$query->the_post();
														$posts_data[] = [
															'post_type' => $post_type,
															'post_type_label' => get_post_type_object($post_type)->labels->singular_name,
															'permalink' => get_permalink(),
															'title' => get_the_title(),
															'time_ago' => human_time_diff(get_the_time('U'), current_time('timestamp')) . ' atrás'
														];
													endwhile;
												endif;
												wp_reset_postdata();
											endforeach;

											// Divide os posts em grupos de 3 para o carousel
											$chunked_posts = array_chunk($posts_data, 2);
											$is_first = true;

											foreach ($chunked_posts as $post_group):
												?>
												<div class="carousel-item <?php echo $is_first ? 'active' : ''; ?>">
													<div class="row">
														<?php foreach ($post_group as $post_data): ?>
															<div class="col-6">
																<div class="card border-0 shadow h-100 publication-card">
																	<div class="card-body">
																		<div class="d-flex align-items-center mb-3">
																			<div class="bg-primary bg-opacity-10 rounded p-2 me-3">
																				<i class="bi <?php echo $post_icon[strtolower($post_data['post_type_label'])] ?>"></i>
																			</div>
																			<span class="badge bg-light text-dark"><?php echo esc_html($post_data['post_type_label']); ?></span>
																		</div>
																		<h6 class="card-title">
																			<a href="<?php echo esc_url($post_data['permalink']); ?>"
																				class="text-dark text-decoration-none">
																				<?php echo $post_data['title']; ?>
																			</a>
																		</h6>
																		<div class="text-muted small mt-2">
																			<i class="bi bi-clock me-1"></i>
																			<?php echo $post_data['time_ago']; ?>
																		</div>
																	</div>
																</div>
															</div>
														<?php endforeach; ?>
													</div>
												</div>
												<?php
												$is_first = false;
											endforeach;
											?>
										</div>
									</div>
								</div>
							</div>

							<!-- Aba do Chat IA -->
							<div class="tab-pane fade card-chat" id="chat-tab-pane" role="tabpanel"
								aria-labelledby="chat-tab" tabindex="0">
								<div class="row">
									<div class="col-12 card-body">
										<?php if ($user_membro_arquivo_privado || current_user_can('administrator') || current_user_can('editor')) { ?>
											<h4 class="mb-4">Fale com a <span class="text-primary">IA do ICODE</span>
											</h4>
											<p class="text-muted mb-4">Como posso ajudar você hoje? Estou aqui para
												responder suas dúvidas sobre o conteúdo do ICODE.</p>
											<div class="chat-container" id="app"></div>
										<?php } else { ?>
											<div class="text-center py-5">
												<img src="<?php echo SITEPATH; ?>assets/img/ic_noite.jpg"
													class="img-fluid rounded-3 mb-4"
													style="max-height: 300px; object-fit: cover;" alt="ICODE Noite" />
												<h4 class="text-muted">Acesso ao Chat IA</h4>
												<p class="text-muted">Soluçao em desenvolvimento e avaliação.</p>
											</div>
										<?php } ?>
									</div>
								</div>
							</div>

						</div>
					</div>
				</div>

			</div>
		</div>
	</section><!-- End Front BOXs Section -->

	<!-- React  -->
	<script src="<?php echo SITEPATH; ?>assets/js/componentMD.js"></script>
	<script src="<?php echo SITEPATH; ?>assets/js/componentChats.js"></script>


	<!-- Script para melhorar a experiência das abas -->
	<script>
		document.addEventListener('DOMContentLoaded', function () {
			// Adiciona transição suave entre abas
			const tabTriggers = [].slice.call(document.querySelectorAll('#myTab button'));
			tabTriggers.forEach(function (tabTrigger) {
				tabTrigger.addEventListener('click', function () {
					// Remove classe ativa de todas as abas
					tabTriggers.forEach(function (trigger) {
						trigger.classList.remove('active');
					});
					// Adiciona classe ativa na aba clicada
					this.classList.add('active');
				});
			});

			// Foca no campo de busca quando a aba de busca é aberta
			document.getElementById('search-tab').addEventListener('click', function () {
				setTimeout(function () {
					document.getElementById('search').focus();
				}, 300);
			});

			// Configuração dos botões do carousel
			const carousel = new bootstrap.Carousel(document.getElementById('publicationsCarousel'), {
				interval: 4000,
				wrap: true
			});

			// Botão anterior
			document.getElementById('carouselPrev').addEventListener('click', function () {
				carousel.prev();
			});

			// Botão próximo
			document.getElementById('carouselNext').addEventListener('click', function () {
				carousel.next();
			});

			// Pausa o carousel quando o mouse está sobre ele
			const carouselElement = document.getElementById('publicationsCarousel');
			carouselElement.addEventListener('mouseenter', function () {
				carousel.pause();
			});

			// Retoma o carousel quando o mouse sai
			carouselElement.addEventListener('mouseleave', function () {
				carousel.cycle();
			});
		});
	</script>

</main><!-- End #main -->

<?php get_footer(); ?>