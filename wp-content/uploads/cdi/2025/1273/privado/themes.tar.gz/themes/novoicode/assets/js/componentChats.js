// Arquivo: wp-content/themes/novoicode/assets/js/componentChats.js

const { useState, useEffect, useRef } = React;

function MarkdownRenderer({ content }) {
    const ReactMarkdown = window.ReactMarkdown;
    if (ReactMarkdown) {
        return React.createElement(ReactMarkdown, {
            components: {
                a: (props) => {
                    return React.createElement('a', {
                        ...props,
                        target: '_blank',
                        rel: 'noopener noreferrer'
                    });
                }
            }
        }, content);
    }
    return React.createElement('div', null, content);
}

function ChatGPTSearch() {
    const [query, setQuery] = useState("");
    const [messages, setMessages] = useState([
        { role: "assistant", content: "**Bem-vindo à IA do ICODE**\n\n*faça uma pergunta ...*" }
    ]);
    const [conversationHistory, setConversationHistory] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [selectedAI, setSelectedAI] = useState("/chatgemini"); // Define Gemini como padrão
    const [spinnerSrc, setSpinnerSrc] = useState("/wp-content/themes/novoicode/assets/img/google.png"); // Define o spinner do Google como padrão

    const textareaRef = useRef(null);

    useEffect(() => {
        if (textareaRef.current) {
            textareaRef.current.focus();
        }
    }, []);

    const handleChange = (event) => {
        setQuery(event.target.value);
    };

    const handleSelectChange = (event) => {
        const selectedValue = event.target.value;
        setSelectedAI(selectedValue);

        const spinnerMap = {
            "/chatic": "/wp-content/themes/novoicode/assets/img/logo2.png",
            "/chatgemini": "/wp-content/themes/novoicode/assets/img/google.png"
        };
        setSpinnerSrc(spinnerMap[selectedValue] || "/wp-content/themes/novoicode/assets/img/default-spinner.png");
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        if (query.trim() === "") return;

        const userMessage = { role: "user", content: query };
        setMessages(prev => [userMessage, ...prev]);
        setQuery("");
        setIsLoading(true);

        try {
            let response;
            if (selectedAI === '/chatgemini') {
                response = await fetch(selectedAI, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        messages: [{ content: query }]
                    })
                });
                const data = await response.json();
                if (
                    data.candidates &&
                    data.candidates.length > 0 &&
                    data.candidates[0].content &&
                    data.candidates[0].content.parts &&
                    data.candidates[0].content.parts.length > 0
                ) {
                    const mainText = data.candidates[0].content.parts[0].text.trim();
                    const fontes = data.candidates[0].content.parts[0].fontes || { posts: [], pdfs: [] };

                    const assistantMessage = {
                        role: "assistant",
                        content: mainText,
                        fontes: fontes
                    };
                    setMessages(prev => [assistantMessage, ...prev]);
                } else {
                    setMessages(prev => [{ role: "assistant", content: "Desculpe, não consegui entender." }, ...prev]);
                    console.error("Resposta inesperada da API Gemini:", data);
                }
            } else if (selectedAI === '/chatic') {
                // Atualiza o histórico com a mensagem do usuário
                const updatedHistory = [...conversationHistory, userMessage];
                setConversationHistory(updatedHistory);

                response = await fetch(selectedAI, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        model: "ICODE-IC:phi4",
                        messages: updatedHistory // Envia todo o histórico de conversa
                    })
                });

                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }

                const data = await response.json();
                if (data.choices && data.choices.length > 0) {
                    const assistantMessage = {
                        role: "assistant",
                        content: data.choices[0].message.content.trim(),
                        fontes: data.fontes // Espera que a API do chatic retorne as fontes
                    };
                    setConversationHistory(prev => [...prev, { role: "assistant", content: data.choices[0].message.content.trim() }]);
                    setMessages(prev => [assistantMessage, ...prev]);
                } else {
                    throw new Error("Resposta inesperada da API");
                }
            }
        } catch (error) {
            console.error("Erro ao chamar a API:", error);
            setMessages(prev => [{ role: "assistant", content: "Ocorreu um erro ao processar a solicitação." }, ...prev]);
        } finally {
            setIsLoading(false);
        }
    };

    const handleKeyDown = (event) => {
        if (event.key === "Enter" && !event.shiftKey) {
            event.preventDefault();
            handleSubmit(event);
        }
    };

    return (
        React.createElement('div', { className: 'chat-container' },
            React.createElement('div', { className: 'messages' },
                messages.map((msg, index) =>
                    React.createElement('div', {
                        key: index,
                        className: `message ${msg.role === 'user' ? 'user-message' : 'assistant-message'}`
                    },
                        React.createElement(MarkdownRenderer, { content: msg.content }),
                        msg.role === 'assistant' && msg.fontes && (msg.fontes.posts.length > 0 || msg.fontes.pdfs.length > 0) &&
                        React.createElement('div', { className: 'fontes-container' },
                            React.createElement('h5', null, 'Fontes Consultadas:'),
                            React.createElement('ul', null,
                                [
                                    ...msg.fontes.posts.map((fonte, idx) =>
                                        React.createElement('li', { key: `post-${idx}` },
                                            React.createElement('a', {
                                                href: fonte.url,
                                                //target: '_blank', 
                                                rel: 'noopener noreferrer'
                                            }, `📌 ${fonte.titulo}`)
                                        )
                                    ),
                                    ...msg.fontes.pdfs.map((fonte, idx) =>
                                        React.createElement('li', { key: `pdf-${idx}` },
                                            React.createElement('a', {
                                                href: fonte.url,
                                                target: '_blank',
                                                rel: 'noopener noreferrer'
                                            }, `📄 ${fonte.nome}`)
                                        )
                                    )
                                ]
                            )
                        )
                    )
                )
            ),
            React.createElement('div', { className: 'input-container' },
                React.createElement('textarea', {
                    ref: textareaRef,
                    className: 'chat-textarea',
                    value: query,
                    onChange: handleChange,
                    onKeyDown: handleKeyDown,
                    placeholder: 'Faça uma pergunta no contexto ICODE ...'
                }),
                React.createElement('div', { className: 'submit-container' },
                    React.createElement('select', {
                        className: 'ai-selector',
                        value: selectedAI,
                        onChange: handleSelectChange
                    },
                        React.createElement('option', { value: '/chatgemini' }, 'Chat-Gemini'),
                        React.createElement('option', { value: '/chatic' }, 'Chat-IC')
                    ),

                    isLoading && React.createElement('img', {
                        src: spinnerSrc,
                        className: 'spinner',
                        alt: 'Carregando...'
                    }),
                    React.createElement('button', { className: 'submit-button', onClick: handleSubmit },
                        React.createElement('i', { className: 'fas fa-arrow-up' })
                    )
                )
            )
        )
    );
}

document.addEventListener('DOMContentLoaded', function () {
    ReactDOM.render(React.createElement(ChatGPTSearch), document.getElementById('app'));
});