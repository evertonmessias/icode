<?php
//Arquivo: wp-content/plugins/novoicode/includes/types/dtc.php
function create_custom_post_type_dtc()
{
	$labels = [
		'name' => _x('DTC', 'post type general name'),
		'singular_name' => _x('DTC', 'post type singular name'),
		'add_new' => _x('Adicionar', 'DTC'),
		'add_new_item' => __('Adicionar novo post DTC'),
		'edit_item' => __('Editar post DTC'),
		'new_item' => __('Novo DTC'),
		'view_item' => __('Ver DTC'),
		'search_items' => __('Buscar DTC'),
		'not_found' =>  __('Nada encontrado'),
		'not_found_in_trash' => __('Nada na lixeira'),
		'parent_item_colon' => ''
	];
	$args = [
		'labels'				=> $labels,
		'supports'              => ['title', 'editor','revisions'],
		'hierarchical'          => false,
        'taxonomies'            => ['category'],
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => false,
		'query_var' 			=> true,
		'menu_position'         => 0,
		'show_in_admin_bar'     => true,
		'rewrite'               => ['slug' => 'dtc/%category%','with_front' => false],
		'show_in_nav_menus'     => true,
		'can_export'			=> true,
		'menu_icon'             => 'dashicons-groups',
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'     	=> ['post', 'dtc'],
		'map_meta_cap'        => true,
	];
	register_post_type('dtc', $args);
}
add_action('init', 'create_custom_post_type_dtc');

// Submenu no admin
function type_dtc()
{
	add_submenu_page('icode', 'DTC', 'DTC', 'edit_posts', 'edit.php?post_type=dtc');
}
add_action('admin_menu', 'type_dtc');

// Permissões
function role_caps_dtc()
{
	$roles = array('editor', 'administrator');
	foreach ($roles as $the_role) {
		$role = get_role($the_role);
		if ($role) {
			$role->add_cap('read');
			$role->add_cap('read_dtc');
			$role->add_cap('read_private_dtc');
			$role->add_cap('edit_dtc');
			$role->add_cap('edit_others_dtc');
			$role->add_cap('edit_published_dtc');
			$role->add_cap('publish_dtc');
			$role->add_cap('delete_others_dtc');
			$role->add_cap('delete_private_dtc');
			$role->add_cap('delete_published_dtc');
		}
	}
}
add_action('admin_init', 'role_caps_dtc', 999);

//******************************************** POST META dtc **************************************************** */

// Privado? ******************************************
function field_box_dtc_privado()
{
	add_meta_box('dtc_privado_id', 'Reunião Privada', 'field_dtc_privado', 'dtc', 'side');
}
add_action('add_meta_boxes', 'field_box_dtc_privado');

function field_dtc_privado($post)
{
	$value = get_post_meta($post->ID, 'dtc_privado', true);
	?>
	<label>
		<input type="checkbox" name='dtc_privado' value="1" <?php checked($value, '1'); ?>>
		Marcar como reunião privada
	</label>
	<?php
}

// Data **********************************************

function field_box_dtc_date()
{
    add_meta_box('dtc_date_id', 'Data da Reunião', 'field_dtc_date', 'dtc', 'advanced');
}
add_action('add_meta_boxes', 'field_box_dtc_date');

function field_dtc_date($post)
{
    $value = get_post_meta($post->ID, 'dtc_date', true);
?>
    <i id="scrollToTop" class='bx bxs-up-arrow-square'></i>
    <input type="datetime-local" name="dtc_date" value="<?php echo $value; ?>">
<?php
}


// Membros **********************************************

function field_box_dtc_member()
{
        add_meta_box('dtc_member_id', 'Membros <small>( preenchimento automático via Intranet )&emsp;</small>', 'field_dtc_member', 'dtc', 'advanced');
}
add_action('add_meta_boxes', 'field_box_dtc_member');

function field_dtc_member($post)
{
    $site = 'dtc';
    if (get_post_meta($post->ID, 'dtc_member', true) == "") {
        $value = do_shortcode('[icapi tipo="composicao_' . $site . '" saida="html/?modo=short"]');
    } else {
        $value = get_post_meta($post->ID, 'dtc_member', true);
    }

    $args = array(
        //'textarea_rows' => 20,
        'textarea_name' => 'dtc_member',
        'media_buttons' => false,
        'quicktags'     => false,
        'tinymce'       => array(
            'toolbar2' => FALSE,
            'media_buttons' => false,
        ),
    );

    wp_editor($value, 'field_dtc_member_id', $args);
?>

<?php
}

//* MOVE  ******************************************************************************************* */


// Move all "advanced" metaboxes after title
add_action('edit_form_after_title', function () {
    global $post, $wp_meta_boxes;
    do_meta_boxes(get_current_screen(), 'advanced', $post);
    unset($wp_meta_boxes[get_post_type($post)]['advanced']);
});

// Move all "default" metaboxes after editor
add_action('edit_form_after_editor', function () {
    global $post, $wp_meta_boxes;
    do_meta_boxes(get_current_screen(), 'default', $post);
    unset($wp_meta_boxes[get_post_type($post)]['default']);
});


/* SAVE ALL ******************************************************************************************* */

add_action('save_post', 'save_postmeta_dtc');

function save_postmeta_dtc($post_id)
{
	// Impede execução em autosave, revisions ou sem permissão
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
	if (is_int(wp_is_post_revision($post_id))) return;
	if (!current_user_can('edit_post', $post_id)) return;

	// Garante que é do tipo correto
	if (get_post_type($post_id) !== 'dtc') return;

	// Salva "privado"
	$privado = isset($_POST['dtc_privado']) ? '1' : '0';
	update_post_meta($post_id, 'dtc_privado', $privado);

	// Salva data
	if (isset($_POST['dtc_date'])) {
		$dtc_date = sanitize_text_field($_POST['dtc_date']);
		update_post_meta($post_id, 'dtc_date', $dtc_date);
	}

	// Salva membros
	if (isset($_POST['dtc_member'])) {
		$dtc_member = wp_kses_post($_POST['dtc_member']);
		update_post_meta($post_id, 'dtc_member', $dtc_member);
	}
}