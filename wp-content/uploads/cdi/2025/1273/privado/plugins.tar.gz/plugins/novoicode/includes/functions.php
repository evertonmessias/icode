<?php
// Arquivo: wp-content/plugins/novoicode/includes/functions.php

//Session
function iniciar_sessao_personalizada()
{
    if (!session_id()) {
        session_start();
    }
}
add_action('init', 'iniciar_sessao_personalizada');

// *****************************************************************************   Redirecionamentos
function icode_redirect()
{
    if (
        !is_user_logged_in() &&
        !is_page('login') &&
        !is_page('googlelogin') &&
        !is_admin() &&
        !(defined('DOING_AJAX') && DOING_AJAX) &&
        !(defined('REST_REQUEST') && REST_REQUEST) &&
        !wp_doing_cron()
    ) {
        error_log('************************ function.php ********************************');

        // Se for a página inicial, redireciona para /perfil após login
        if ($_SERVER['REQUEST_URI'] == '/' || $_SERVER['REQUEST_URI'] == '' || $_SERVER['REQUEST_URI'] == '/favicon.ico') {
            $redirect_to = home_url('/perfil');
        } else {
            $redirect_to = home_url($_SERVER['REQUEST_URI']);
        }

        if (empty($_SESSION['ldap_login_redirect'])) {
            $_SESSION['ldap_login_redirect'] = $redirect_to; // cria a Sessão
            error_log('Iniciada SESSION no functions.php icode_redirect() ==> ' . $_SESSION['ldap_login_redirect']);
        }

        $login_url = home_url('/login') . '?redirect_to=' . urlencode($_SESSION['ldap_login_redirect']);

        error_log($login_url);

        wp_redirect($login_url);
        exit;
    }
}
add_action('template_redirect', 'icode_redirect');



// ************************************************************************************** Lista de Usuários

//************* Docentes Site IC
function lista_docentes_site_ic()
{
    // URL da API da intranet
    $url = 'https://intranet.ic.unicamp.br/pub/docentes/siteic';

    // Inicializa cURL para obter o conteúdo da API
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Para evitar problemas com SSL
    $response = curl_exec($ch);
    curl_close($ch);

    // Verifica se a resposta foi obtida com sucesso
    if ($response === false) {
        die('Não foi possível acessar a API.');
    }

    // Decodifica o JSON da resposta
    $data = json_decode($response, true);

    // Verifica se a decodificação foi bem-sucedida
    if (json_last_error() !== JSON_ERROR_NONE) {
        die('Erro ao decodificar JSON: ' . json_last_error_msg());
    }

    // Array para armazenar os dados formatados
    $docentes = [];

    // Itera sobre os docentes ativos
    if (isset($data['data']['ativos']) && is_array($data['data']['ativos'])) {
        foreach ($data['data']['ativos'] as $docente_api) {
            $docente = [];

            // Mapeia os campos da API para o formato desejado
            $docente['nome'] = trim($docente_api['Nome'] ?? '');
            $docente['photo_url'] = $docente_api['Foto Pessoal'] ?? null;
            $docente['cargo'] = $docente_api['Cargo'] ?? '';
            $docente['email'] = $docente_api['Email'] ?? '';

            // Extrai a sigla do departamento (últimas 3 letras)
            $departamento = $docente_api['Departamento'] ?? '';
            preg_match('/ - (\bD[STC][SICT]\b)$/', $departamento, $matches);
            $docente['departamento'] = $matches[1] ?? '';

            // Adiciona campos adicionais disponíveis na API
            $docente['matricula'] = $docente_api['Matrícula'] ?? '';
            $docente['nivel'] = $docente_api['Nível'] ?? '';
            $docente['regime'] = $docente_api['Regime'] ?? '';
            $docente['descricao_regime'] = $docente_api['Descrição do Regime'] ?? '';
            $docente['titulacao'] = $docente_api['Titulação'] ?? '';
            $docente['telefone'] = $docente_api['Telefone'] ?? '';
            $docente['sala'] = $docente_api['Sala'] ?? '';
            $docente['email_sise'] = $docente_api['Email SISE'] ?? '';
            $docente['lattes'] = $docente_api['Currículo Lattes'] ?? '';
            $docente['pagina_pessoal'] = $docente_api['Página Pessoal'] ?? '';
            $docente['video_apresentacao'] = $docente_api['Video de Apresentação'] ?? '';
            $docente['areas_interesse'] = $docente_api['Areas de Interesse'] ?? [];

            $docentes[] = $docente;
        }
    }

    // Converte para JSON
    $json = json_encode($docentes, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

    // Exibe o JSON
    return $json;
}
add_action("lista_docentes_site_ic", "lista_docentes_site_ic");



//************* Funcionarios Site IC
function lista_funcionarios_site_ic()
{
    // URL da API da intranet
    $url = 'https://intranet.ic.unicamp.br/pub/funcionarios/siteic';

    // Inicializa cURL para obter o conteúdo da API
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Para evitar problemas com SSL
    $response = curl_exec($ch);
    curl_close($ch);

    // Verifica se a resposta foi obtida com sucesso
    if ($response === false) {
        die('Não foi possível acessar a API.');
    }

    // Decodifica o JSON da resposta
    $data = json_decode($response, true);

    // Verifica se a decodificação foi bem-sucedida
    if (json_last_error() !== JSON_ERROR_NONE) {
        die('Erro ao decodificar JSON: ' . json_last_error_msg());
    }

    // Array para armazenar os dados formatados
    $funcionarios = [];

    // Itera sobre os funcionários ativos
    if (isset($data['data']['ativos']) && is_array($data['data']['ativos'])) {
        foreach ($data['data']['ativos'] as $funcionario_api) {
            $funcionario = [];

            // Mapeia os campos da API para o formato desejado
            $funcionario['nome'] = trim($funcionario_api['Nome'] ?? '');
            $funcionario['photo_url'] = $funcionario_api['Foto Pessoal'] ?? null;
            $funcionario['cargo'] = $funcionario_api['Cargo'] ?? '';
            $funcionario['email'] = $funcionario_api['Email'] ?? '';

            // Adiciona campos adicionais disponíveis na API
            $funcionario['matricula'] = $funcionario_api['Matrícula'] ?? '';
            $funcionario['regime'] = $funcionario_api['Regime'] ?? '';
            $funcionario['descricao_regime'] = $funcionario_api['Descrição do Regime'] ?? '';
            $funcionario['secao'] = $funcionario_api['Seção'] ?? '';
            $funcionario['telefone'] = $funcionario_api['Telefone'] ?? '';
            $funcionario['sala'] = $funcionario_api['Sala'] ?? '';
            $funcionario['email_sise'] = $funcionario_api['Email SISE'] ?? '';
            $funcionario['processos_trabalho'] = $funcionario_api['Processos de Trabalho'] ?? [];

            $funcionarios[] = $funcionario;
        }
    }

    // Converte o array de funcionários para JSON
    $json = json_encode($funcionarios, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

    // Exibe o JSON
    return $json;
}
add_action("lista_funcionarios_site_ic", "lista_funcionarios_site_ic");


// ************* Retorna Avatar
function retornaPhoto($email)
{
    $photo_url = "";
    $site_docentes = json_decode(lista_docentes_site_ic());
    foreach ($site_docentes as $site_docente) {
        if ($site_docente->email == $email) {
            $photo_url = $site_docente->photo_url;
        }
    }
    $site_funcionarios = json_decode(lista_funcionarios_site_ic());
    foreach ($site_funcionarios as $site_funcionario) {
        if ($site_funcionario->email == $email) {
            $photo_url = $site_funcionario->photo_url;
        }
    }
    return $photo_url;
}
add_action("retornaPhoto", "retornaPhoto");

// ************* Importar Avatar imagem para midia
function importar_imagem_para_midia($image_url, $user_id)
{
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    require_once(ABSPATH . 'wp-admin/includes/image.php');

    $tmp = download_url($image_url);
    if (is_wp_error($tmp))
        return false;

    $file_array = [
        'name' => basename(parse_url($image_url, PHP_URL_PATH)),
        'tmp_name' => $tmp
    ];

    $attachment_id = media_handle_sideload($file_array, 0);
    if (is_wp_error($attachment_id)) {
        @unlink($tmp);
        return false;
    }

    return $attachment_id;
}


// ********** custom_user_avatar_if_available in user.php
function custom_user_avatar_if_available($avatar, $id_or_email, $size, $default, $alt)
{
    $user = false;

    // Garantir que estamos lidando com um ID de usuário
    if (is_numeric($id_or_email)) {
        $user = get_user_by('id', $id_or_email);
    } elseif (is_object($id_or_email) && isset($id_or_email->user_id)) {
        $user = get_user_by('id', $id_or_email->user_id);
    } elseif (is_string($id_or_email)) {
        $user = get_user_by('email', $id_or_email);
    }

    if ($user) {
        $avatar_id = get_user_meta($user->ID, 'wp_user_avatar', true);
        if ($avatar_id) {
            $avatar_url = wp_get_attachment_image_url($avatar_id, 'thumbnail');
            if ($avatar_url) {
                return "<img alt='" . esc_attr($alt) . "' src='" . esc_url($avatar_url) . "' class='avatar avatar-{$size} photo' height='{$size}' width='{$size}' />";
            }
        }
    }

    // Se não tiver avatar personalizado, retorna o padrão (Gravatar)
    return $avatar;
}
add_filter('get_avatar', 'custom_user_avatar_if_available', 10, 5);


// ********** Usuários Intranet
function lista_usuarios_intranet($pessoa, $sistema)
{
    $url_intranet = "https://intranet.ic.unicamp.br/pub/" . $pessoa;
    $dados = json_decode(file_get_contents($url_intranet));

    $usuario = [];

    foreach ($dados->data as $user) {
        if ($sistema == 'ldap' && $user->Email) {
            $usuario[] = $user->Email;
        }
        if ($sistema == 'sise' && $user->{'Email SISE'}) {
            $usuario[] = $user->{'Email SISE'};
        }
    }
    return $usuario;
}
add_action("lista_usuarios_intranet", "lista_usuarios_intranet");



// ********************* Lista Usuários por Departamento na Intranet
function lista_usuarios_depto($depto)
{
    $url_intranet = "https://intranet.ic.unicamp.br/pub/composicao_" . $depto . "/json?modo=short";
    $dados = json_decode(file_get_contents($url_intranet));

    $emails = [];

    // Chefe
    if (isset($dados->data->chefe->email_inst)) {
        $emails[] = $dados->data->chefe->email_inst;
    }
    if (isset($dados->data->chefe->email_sise)) {
        $emails[] = $dados->data->chefe->email_sise;
    }

    // Vice-Chefe
    if (isset($dados->data->vice_chefe->email_inst)) {
        $emails[] = $dados->data->vice_chefe->email_inst;
    }
    if (isset($dados->data->vice_chefe->email_sise)) {
        $emails[] = $dados->data->vice_chefe->email_sise;
    }

    // Secretaria Acadêmica
    if (isset($dados->data->sec_acad->email_inst)) {
        $emails[] = $dados->data->sec_acad->email_inst;
    }
    if (isset($dados->data->sec_acad->email_sise)) {
        $emails[] = $dados->data->sec_acad->email_sise;
    }

    // Docentes
    if (isset($dados->data->docentes) && is_array($dados->data->docentes)) {
        foreach ($dados->data->docentes as $docente) {
            if (isset($docente->email_inst)) {
                $emails[] = $docente->email_inst;
            }
            if (isset($docente->email_sise)) {
                $emails[] = $docente->email_sise;
            }
        }
    }

    // Titulares
    if (isset($dados->data->titulares) && is_array($dados->data->titulares)) {
        foreach ($dados->data->titulares as $titular) {
            if (isset($titular->email_inst)) {
                $emails[] = $titular->email_inst;
            }
            if (isset($titular->email_sise)) {
                $emails[] = $titular->email_sise;
            }
        }
    }

    // Suplentes
    if (isset($dados->data->suplentes) && is_array($dados->data->suplentes)) {
        foreach ($dados->data->suplentes as $suplente) {
            if (isset($suplente->email_inst)) {
                $emails[] = $suplente->email_inst;
            }
            if (isset($suplente->email_sise)) {
                $emails[] = $suplente->email_sise;
            }
        }
    }

    return $emails;
}
add_action("lista_usuarios_depto", "lista_usuarios_depto");


// *************** Papel do Usuário
function papel_usuario($email)
{
    $emails_editores = get_option('portal_input_2', []);
    $emails_admin = get_option('portal_input_4', []);

    if (!is_array($emails_editores))
        $emails_editores = [];
    if (!is_array($emails_admin))
        $emails_admin = [];

    $emails_editores = array_map('strtolower', $emails_editores);
    $emails_admin = array_map('strtolower', $emails_admin);

    if (in_array($email, $emails_admin, true)) {
        $role = 'administrator';
    } elseif (in_array($email, $emails_editores, true)) {
        $role = 'editor';
    } else {
        $role = 'subscriber';
    }
    return $role;
}
add_action('papel_usuario', 'papel_usuario');


// ******************* Retorna Membro Intranet
function retorna_membro($email)
{
    $grupos = [];

    if (in_array($email, lista_usuarios_depto("congrega"), true)) {
        $grupos[] = "congrega";
    }

    if (in_array($email, lista_usuarios_depto("ci"), true)) {
        $grupos[] = "ci";
    }

    if (in_array($email, lista_usuarios_depto("dsc"), true)) {
        $grupos[] = "dsc";
    }

    if (in_array($email, lista_usuarios_depto("dsi"), true)) {
        $grupos[] = "dsi";
    }

    if (in_array($email, lista_usuarios_depto("dtc"), true)) {
        $grupos[] = "dtc";
    }

    if (in_array($email, lista_usuarios_depto("cdi"), true)) {
        $grupos[] = "cdi";
    }

    return $grupos;
}
add_action('retorna_membro', 'retorna_membro');


function retorna_membro_siteic($email)
{
    $grupos = [];
    // Pesquisa na intranet siteic
    $lista = json_decode(lista_docentes_site_ic());
    foreach ($lista as $professor) {
        if (isset($professor->email) && $professor->email == $email) {
            $grupos[] = strtolower($professor->departamento);
            break;
        }
    }
    return $grupos;
}
add_action('retorna_membro_siteic', 'retorna_membro_siteic');



// ************************** Tradução Roles/Papel
function traduz_papel($role)
{
    $papel = "";
    if ($role == 'administrator') {
        $papel = "Administrador";
    }
    if ($role == 'editor') {
        $papel = "Editor";
    }
    if ($role == 'subscriber') {
        $papel = "Assinante";
    }
    return $papel;
}
add_action('traduz_papel', 'traduz_papel');



// ************************** Permite URL
function permite_url($url, $user_id)
{
    error_log('Verifica function.php permite_url() ==> ' . $url);
    $url_membro = explode("/", $url)[5]; // retorna membro da url (congrega,ci,dsc,dsi,dtc,cdi)
    $url_membro_arquivo_privado = explode("/", $url)[8]; // retorna subdir da url (ata,deliberacoes,pautas,privado)

    $grupo_user_membro = get_user_meta($user_id, 'membro', true); // retorna grupo membros do usuário
    $grupo_user_privado = get_user_meta($user_id, 'membro_arquivo_privado', true); // retorna grupo membros privado do usuario

    $tem_acesso_membro = in_array($url_membro, $grupo_user_membro, true); // bool
    $tem_acesso_privado = in_array($url_membro, $grupo_user_privado, true); // bool

    $permitido = false;

    if ($url_membro_arquivo_privado === 'privado') {
        $permitido = $tem_acesso_membro && $tem_acesso_privado;
    } else {
        $permitido = $tem_acesso_membro;
    }
    $log_resp = $permitido ? "Permitido OK para " . get_userdata($user_id)->user_login : "Permissão Negada para " . get_userdata($user_id)->user_login;
    error_log($log_resp);
    return $permitido;
}
add_action('permite_url', 'permite_url');




//************* Admin Login Customization ***********************************************************
function tf_wp_admin_login_customization()
{ ?>

    <link href="<?php echo get_option('portal_input_1'); ?>" rel="icon">
    <style type="text/css">
        .login {
            background-color: #F6F9FF;
        }

        .login h1 {
            margin-bottom: -25px;
        }

        #login h1 a {
            background-image: url('<?php echo get_option('portal_input_1'); ?>');
        }

        #login #wp-submit {
            background-color: #126EEA;
        }

        #login .galogin-powered,
        #login .galogin-or,
        p#backtoblog,
        .language-switcher,
        p#nav {
            display: none;
        }

        .custom-login-title {
            text-align: center;
            font-size: 30px;
            font-weight: bold;
            color: #126EEA;
            margin-bottom: 20px;
        }

        .login-button {
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #fff;
            color: #000;
            border: 1px solid #ccc;
            padding: 10px 0px !important;
            border-radius: 5px;
            text-decoration: none;
            width: 100%;
            margin: 0 auto 20px auto !important;
            cursor: pointer !important;
        }

        .login-button img {
            width: 20px;
            height: auto;
            margin-right: 10px;
        }

        .ic-login-fields {
            display: none;
            transition: all 0.5s ease;
            margin-top: 20px;
        }

        .btn.btn-link {
            margin-top: 5px;
            padding: 6px;
            border-radius: 4px;
            background: #aaa;
            cursor: pointer;
            border: 0;
            color: #fff;
        }

        #login .galogin-powered,
        #login .galogin-or,
        p#backtoblog,
        .language-switcher,
        #loginform>div.ic-login-fields>button,
        .forgetmenot,
        p#nav {
            display: none !important;
        }

        .login form .input {
            font-size: 18px !important;
        }
    </style>

    <script type="text/javascript">
        document.addEventListener("DOMContentLoaded", function () {
            const loginForm = document.querySelector(".login form");
            if (!loginForm) return;

            // Título
            const title = document.createElement("div");
            title.className = "custom-login-title";
            title.innerText = "ICODE";
            loginForm.parentNode.insertBefore(title, loginForm);

            // Botão Login unicamp
            const googleLoginDiv = document.createElement("div");
            const googleLoginLink = document.createElement("a");
            googleLoginLink.className = "login-button";

            let redirectToParam = "";
            const icodeurl = window.location.href;
            if (icodeurl.includes(".pdf")) {
                redirectToParam = icodeurl;
            } else {
                const urlParams = new URLSearchParams(window.location.search);
                redirectToParam = urlParams.get("redirect_to");
            }
            const redirectTo = redirectToParam ? redirectToParam : "/perfil";

            googleLoginLink.href = "<?php echo esc_url(site_url('/googlelogin')); ?>" + "?redirect_to=" + encodeURIComponent(redirectTo);

            const googleLoginImage = document.createElement("img");
            googleLoginImage.src = "<?php echo get_stylesheet_directory_uri(); ?>/assets/img/unicamp.png";
            googleLoginImage.alt = "Login @unicamp , @dac";
            googleLoginLink.appendChild(googleLoginImage);
            googleLoginLink.appendChild(document.createTextNode("Login @unicamp , @dac"));

            googleLoginDiv.appendChild(googleLoginLink);
            loginForm.insertBefore(googleLoginDiv, loginForm.firstChild);

            // Botão Login com IC
            const icLoginDiv = document.createElement("div");
            const icToggleButton = document.createElement("button");
            icToggleButton.className = "login-button";
            icToggleButton.type = "button";

            const icLoginImage = document.createElement("img");
            icLoginImage.src = "<?php echo get_stylesheet_directory_uri(); ?>/assets/img/logo.png";
            icLoginImage.alt = "Login com IC";
            icToggleButton.appendChild(icLoginImage);
            icToggleButton.appendChild(document.createTextNode("Login com LDAP-IC"));
            icLoginDiv.appendChild(icToggleButton);
            loginForm.insertBefore(icLoginDiv, googleLoginDiv.nextSibling);

            // Agrupar campos ocultos inicialmente
            const icFieldsWrapper = document.createElement("div");
            icFieldsWrapper.className = "ic-login-fields";

            const userField = document.querySelector("#user_login")?.closest("p");
            const passField = document.querySelector(".user-pass-wrap");
            const rememberField = document.querySelector(".forgetmenot");
            const submitField = document.querySelector(".submit");

            if (userField) icFieldsWrapper.appendChild(userField);
            if (passField) icFieldsWrapper.appendChild(passField);
            if (rememberField) icFieldsWrapper.appendChild(rememberField);
            if (submitField) icFieldsWrapper.appendChild(submitField);

            loginForm.insertBefore(icFieldsWrapper, icLoginDiv.nextSibling);

            // Esconde labels
            document.querySelectorAll(".login form label").forEach(function (label) {
                label.style.display = "none";
            });

            // Placeholders e disabled inicial
            const userInput = document.querySelector("#user_login");
            const passInput = document.querySelector("#user_pass");

            if (userInput) {
                userInput.setAttribute("placeholder", "Usuário IC");
                userInput.setAttribute("disabled", "true");
            }

            if (passInput) {
                passInput.setAttribute("placeholder", "Senha IC");
                passInput.setAttribute("disabled", "true");
            }

            // Link "Perdeu a senha?"
            const lostPasswordLink = document.querySelector(".wp-login-lost-password");
            if (lostPasswordLink) {
                const lostPasswordButton = document.createElement("button");
                lostPasswordButton.className = "btn btn-link";
                lostPasswordButton.type = "button";
                lostPasswordButton.innerText = "Perdeu a senha?";
                lostPasswordButton.onclick = function () {
                    window.location.href = lostPasswordLink.href;
                };
                lostPasswordLink.parentNode.removeChild(lostPasswordLink);
                icFieldsWrapper.appendChild(lostPasswordButton);
            }

            // Sanfona: Mostrar / ocultar e ativar/desativar campos
            let icVisible = false;
            icToggleButton.addEventListener("click", function () {
                icVisible = !icVisible;
                if (icVisible) {
                    icFieldsWrapper.style.display = "block";
                    if (userInput) userInput.removeAttribute("disabled");
                    if (passInput) passInput.removeAttribute("disabled");
                    icFieldsWrapper.scrollIntoView({ behavior: "smooth" });
                } else {
                    icFieldsWrapper.style.display = "none";
                    if (userInput) userInput.setAttribute("disabled", "true");
                    if (passInput) passInput.setAttribute("disabled", "true");
                }
            });
        });
    </script>
<?php }
add_action('login_enqueue_scripts', 'tf_wp_admin_login_customization');




//************* Admin Login Logo Link URL *****************************************************************
function tf_wp_admin_login_logo_url()
{
    return home_url();
}
add_filter('login_headerurl', 'tf_wp_admin_login_logo_url');




//************* Admin Login Logo's Title *****************************************************************
function tf_wp_admin_login_logo_title($headertext)
{
    $headertext = esc_html__(get_bloginfo('name'), 'plugin-textdomain');
    return $headertext;
}
add_filter('login_headertext', 'tf_wp_admin_login_logo_title');




//// ************************** Usuário IC login ***************************
function usuarioIClogin($username, $password)
{
    $postFields = http_build_query([
        'username' => $username,
        'password' => $password
    ]);

    $resp = false;

    $ch = curl_init('https://auth.ic.unicamp.br/login');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);

    $response = curl_exec($ch);
    curl_close($ch);
    $json = json_decode($response);

    if (isset($json->username_ic)) {
        $resp = [$json->nome, $json->username_ic, $json->username_unicamp];
    }
    return $resp;
}



//// ************************** Usuario IC dados ***************************
function usuarioICdados($usernameic)
{
    // Define o ref com base no username
    $ref = preg_match('/^ra\d{6}$/', $usernameic) ? 'lab' : 'ic';

    $resp = false;

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://auth.ic.unicamp.br/ldapsearch');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, [
        'username' => $usernameic,
        'ref' => $ref
    ]);

    $response = curl_exec($ch);
    curl_close($ch);
    $json = json_decode($response);

    if (isset($json->data->mail)) {
        $resp = [$json->data->mail, $json->data->givenname, $json->data->sn];
    }
    return $resp;

}



// ************************************************************************************* Login WP com LDAP
function custom_wp_authenticate($user, $username, $password)
{
    if (empty($username) || empty($password)) {
        if (isset($_POST['log']) && isset($_POST['pwd'])) {
            return new WP_Error('empty_credentials', __('Usuário e senha são obrigatórios.'));
        }
        return null;
    }

    $username = strtolower($username);

    // Permitir login local apenas para o admin
    if ($username === 'admin') {
        remove_filter('authenticate', 'custom_wp_authenticate', 10);
        $user = wp_authenticate_username_password(null, $username, $password);
        add_filter('authenticate', 'custom_wp_authenticate', 10, 3);

        if (is_wp_error($user)) {
            return new WP_Error('wp_auth_failed', __('Falha na autenticação do WordPress para admin.'));
        }

        return $user;
    }

    $resultado_ic = usuarioIClogin($username, $password);

    if (!$resultado_ic) {
        wp_die("Usuário ou senha inválidos");
    }

    // Descompacta os dados retornados
    list($email, $first_name, $last_name) = usuarioICdados($username);


    if ($email) {

        $user = get_user_by('login', $username);

        if (!$user) {
            $user_id = wp_create_user($username, wp_generate_password(), $email);

            if (is_wp_error($user_id)) {
                error_log('Debug LDAP: Erro ao criar usuário WP: ' . $user_id->get_error_message());
                return new WP_Error('user_creation_failed', __('Falha ao criar o usuário no WordPress.'));
            }

            wp_update_user([
                'ID' => $user_id,
                'role' => papel_usuario($email),
                'first_name' => $first_name,
                'last_name' => $last_name
            ]);

            $user = get_user_by('id', $user_id);

            $photo_url = retornaPhoto($email);
            $avatar_id = importar_imagem_para_midia($photo_url, $user->ID);
            if ($avatar_id) {
                update_user_meta($user->ID, 'wp_user_avatar', $avatar_id);
            }

            error_log('Debug LDAP: Usuário WP criado para ' . $username . ' com ID: ' . $user->ID);

        } else {
            error_log('Debug LDAP: Usuário WP existente encontrado para ' . $username . ' com ID: ' . $user->ID);
        }

        // --- Depuração: Atualizando user meta
        error_log('Debug LDAP: Atualizando user meta para usuário: ' . $user->ID);

        $tipos_registrados = ['congrega', 'ci', 'dsc', 'dsi', 'dtc', 'cdi'];

        // *** USER META
        // em membros , primeiro revoga tudo
        update_user_meta($user->ID, 'membro', null);
        update_user_meta($user->ID, 'membro_arquivo_privado', null);
        update_user_meta($user->ID, 'membro_post_privado', null);

        // depois reclassifica
        if (papel_usuario($email) == 'editor' || papel_usuario($email) == 'administrator') {
            update_user_meta($user->ID, 'membro', $tipos_registrados);
            update_user_meta($user->ID, 'membro_arquivo_privado', $tipos_registrados);
            update_user_meta($user->ID, 'membro_post_privado', $tipos_registrados);
            error_log('Debug LDAP: Usuário classificado como editor/admin. Membros setados.');
        } else {
            $grupos = retorna_membro($email); // verifica na intranet

            if (!in_array('congrega', $grupos)) {
                $grupos[] = 'congrega';
            }

            if (!in_array('ci', $grupos)) {
                $grupos[] = 'ci';
            }

            if (count($grupos) === 2 && !array_diff($grupos, ['congrega', 'ci']) && !array_diff(['ci', 'congrega'], $grupos)) {
                $grupos = array_merge($grupos, retorna_membro_siteic($email));
            }

            update_user_meta($user->ID, 'membro', $grupos);
            update_user_meta($user->ID, 'membro_arquivo_privado', retorna_membro($email));
            error_log('Debug LDAP: Usuário classificado como membro. Grupos: ' . implode(', ', $grupos));
        }

        // Autenticação e login
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID);
        do_action('wp_login', $user->user_login, $user);
        error_log('Debug LDAP: wp_set_current_user, wp_set_auth_cookie e wp_login hooks disparados.');


        // REDIRECIONAMENTO
        if (get_user_meta($user->ID, 'aceite', true)) { //verifica se user aceitou 
            $redirect_to = $_SESSION['ldap_login_redirect'];

        } else {
            $redirect_to = home_url('/perfil');
        }

        error_log('Redirecionamento function.php ldap() ==> ' . $redirect_to);

        wp_redirect($redirect_to);
        exit;

    }

}
add_filter('authenticate', 'custom_wp_authenticate', 10, 3);




// ****************************************************** Remove "Perdeu a senha?" das mensagens de erro
add_filter('login_errors', function ($error) {
    return preg_replace('/<a.*?lostpassword.*?<\/a>/', '', $error);
});


// ************************************************************************************* SMTP
function configurar_smtp()
{
    add_action('phpmailer_init', 'wp_smtp');
}

function wp_smtp($phpmailer)
{
    $phpmailer->isSMTP();
    $phpmailer->Host = SMTP_HOST;
    $phpmailer->SMTPAuth = true;
    $phpmailer->Username = SMTP_USER;
    $phpmailer->Password = SMTP_PASS;
    $phpmailer->SMTPSecure = SMTP_SECURE;
    $phpmailer->Port = SMTP_PORT;
    $phpmailer->From = SMTP_FROM;
    $phpmailer->FromName = SMTP_NAME;
}

add_action('init', 'configurar_smtp');

// **************************************************************** Add style & script for Admin

function styles_and_scripts_plugin()
{
    wp_enqueue_script("jquery");
    wp_enqueue_style("datatable-css", "https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css");
    wp_enqueue_style("datatable-buttons-css", "https://cdn.datatables.net/buttons/1.5.6/css/buttons.dataTables.min.css");
    wp_enqueue_style("bootstrap5-css", "https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css");
    wp_enqueue_style("custom-css", "/wp-content/plugins/novoicode/assets/css/novoicode.css");

    wp_enqueue_script("datatable-js", "https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js", array("jquery"), null, true);
    wp_enqueue_script("datatable-buttons-js", "https://cdn.datatables.net/buttons/1.5.6/js/dataTables.buttons.min.js", array("jquery"), null, true);
    wp_enqueue_script("datatable-buttons-html5-js", "https://cdn.datatables.net/buttons/1.5.6/js/buttons.html5.min.js", array("jquery"), null, true);
    wp_enqueue_script("bootstrap5-js", "https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js", array("jquery"), null, true);
    wp_enqueue_script("custom-js", "/wp-content/plugins/novoicode/assets/js/novoicode.js", array("jquery"), null, true);
}
add_action("admin_enqueue_scripts", "styles_and_scripts_plugin");



//***************** Add General Configuration Roles **************************************************
function general_configuration_role_caps()
{
    $roles = array('editor');
    foreach ($roles as $the_role) {
        $role = get_role($the_role);

        // Removendo permissões de gerenciamento de usuários
        $role->remove_cap('list_users');
        $role->remove_cap('create_users');
        $role->remove_cap('remove_users');
        $role->remove_cap('promote_users');
        $role->remove_cap('edit_users');

        // Adicionando permissões de gerenciamento geral
        $role->add_cap('manage_options');

        // Adicionando permissões para criar, editar e excluir qualquer post
        $role->add_cap('edit_posts');
        $role->add_cap('edit_others_posts');
        $role->add_cap('publish_posts');
        $role->add_cap('delete_posts');
        $role->add_cap('delete_others_posts');
        $role->add_cap('edit_published_posts');
        $role->add_cap('delete_published_posts');
    }
}
add_action('admin_init', 'general_configuration_role_caps', 999);


//Rename menu iten Admin *********************************************************
function wd_admin_menu_rename()
{
    global $menu;
    //$menu[5][0] = 'Blog IC';
}
add_action('admin_menu', 'wd_admin_menu_rename');

// Admin Bar
add_action('after_setup_theme', function () {
    if (current_user_can('administrator')) {
        show_admin_bar(false);
    } else {
        show_admin_bar(false);
    }
});

// Block wp-admin *********************************************************************************
// Bloquear acesso ao /wp-admin para editores, exceto admin-post.php
function bloquear_acesso_admin()
{
    if (is_admin() && !current_user_can('administrator')) {
        // Permitir acesso ao admin-post.php para processar os formulários
        $pagina_permitida = strpos($_SERVER['REQUEST_URI'], 'admin-post.php') !== false;

        if (!$pagina_permitida && !(defined('DOING_AJAX') && DOING_AJAX)) {
            wp_redirect(home_url('/404'));
            exit;
        }
    }
}
add_action('init', 'bloquear_acesso_admin');



// ***************** Add in Menu ******************************************************************
function menu_icode()
{
    add_menu_page('ICODE', 'ICODE', 'edit_posts', 'icode', 'function_about', 'dashicons-screenoptions', 1);
    add_submenu_page('icode', 'Acessos', 'Acessos', 'edit_posts', 'acessos', 'function_acessos', 2);
    add_submenu_page('icode', 'PDFParser', 'PDFParser', 'edit_posts', 'pdfparser', 'function_pdfparser', 3);
}

add_action('admin_menu', 'menu_icode');

// ***************** Add About ************************************************************
function function_about()
{
    include ABSPATH . '/wp-content/plugins/novoicode/includes/about.php';
}
add_action('function_about', 'function_about');

// ***************** Add Acessos ***************************************************************
function function_acessos()
{
    include ABSPATH . '/wp-content/plugins/novoicode/includes/acessos.php';
}
add_action('function_acessos', 'function_acessos');

// ***************** Add page pdfparser ******************************************************
function function_pdfparser()
{
    include ABSPATH . '/wp-content/plugins/novoicode/includes/pdfparser.php';
}
add_action('function_pdfparser', 'function_pdfparser');

//************* Data Base *******************************************************************

function registerdb($user = NULL, $ip = NULL, $url = NULL) // register in db
{
    global $wpdb;

    if ($user == NULL) {
        $user = " --- ";
    }
    if ($url == NULL) {
        $url = "/";
    }
    $table_name = $wpdb->prefix . 'acessos';
    $wpdb->insert($table_name, array('user' => $user, 'ipadress' => $ip, 'url' => $url, 'time' => current_time('mysql')));
}
add_action('registerdb', 'registerdb');

//************* IC - APIs ***************************************************************
function icapi($attr)
{
    if ($attr['tipo'] == "" || $attr['saida'] == "") {

        return "<h4 class='center red'>ERRO!</h4>";
    } else {

        $tipo = "/" . $attr['tipo'];

        $saida = "/" . $attr['saida'];

        $string = 'https://intranet.ic.unicamp.br/pub' . $tipo . $saida;

        $url = file_get_contents($string);

        return $url . "<h1>&nbsp;</h1><small class='fonte'><b>Fonte</b>:&ensp;<a href='" . $string . "' target='_blank'>" . $string . "</a></small>";
    }
}
add_shortcode('icapi', 'icapi');


// ********************* CATEGORY YEAR (Gerar categorias de ano se não existirem) *******************
function create_year_categories()
{
    $start_year = 2004;
    $current_year = date('Y');

    for ($year = $start_year; $year <= $current_year; $year++) {
        if (!term_exists($year, 'category')) {
            wp_insert_term($year, 'category', [
                'slug' => $year,
            ]);
        }
    }
}
add_action('init', 'create_year_categories');

// ********************* METABOX COM SELECT DE ANOS PARA O POST TYPE  *********************
function add_year_category_metabox()
{
    add_meta_box(
        'year_category_select',
        'Ano',
        'render_year_category_metabox',
        ['congrega', 'ci', 'dsc', 'dsi', 'dtc', 'cdi'],
        'side',
        'default'
    );
}
add_action('add_meta_boxes', 'add_year_category_metabox');

function render_year_category_metabox($post)
{
    $selected = '';
    $terms = wp_get_post_terms($post->ID, 'category', ['fields' => 'slugs']);
    if (!empty($terms)) {
        $selected = $terms[0];
    }

    $start_year = 2004;
    $current_year = date('Y');

    echo '<select name="year_category_select" style="width:100%;">';
    echo '<option value="">-- Selecione o Ano --</option>';

    for ($year = $current_year; $year >= $start_year; $year--) {
        $is_selected = ($selected == $year) ? 'selected' : '';
        echo "<option value='{$year}' {$is_selected}>{$year}</option>";
    }

    echo '</select>';
    // Campo nonce para segurança
    wp_nonce_field('save_year_category_metabox', 'year_category_metabox_nonce');
}

// ********************* SALVAR SELEÇÃO *******************************************************
function save_year_category_selection($post_id)
{
    // Verificações de segurança
    if (
        !isset($_POST['year_category_metabox_nonce']) ||
        !wp_verify_nonce($_POST['year_category_metabox_nonce'], 'save_year_category_metabox')
    ) {
        return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
        return;
    if (!current_user_can('edit_post', $post_id))
        return;

    if (isset($_POST['year_category_select']) && $_POST['year_category_select'] !== '') {
        $year_slug = sanitize_text_field($_POST['year_category_select']);
        $term = get_term_by('slug', $year_slug, 'category');
        if ($term) {
            wp_set_post_terms($post_id, [$term->term_id], 'category');
        }
    }
}
add_action('save_post', 'save_year_category_selection');

// ********************* PRÉ SELECT CAT ******************************************************
function preselect_category_for_custom_type($post_ID, $post, $update)
{
    if (!$update && ($post->post_type === 'congrega' || $post->post_type === 'ci' || $post->post_type === 'dsc' || $post->post_type === 'dsi' || $post->post_type === 'dtc' || $post->post_type === 'cdi')) {
        $current_year = date('Y');
        $term = get_term_by('slug', $current_year, 'category');

        if ($term) {
            wp_set_post_terms($post_ID, [$term->term_id], 'category');
        }
    }
}
add_action('wp_insert_post', 'preselect_category_for_custom_type', 10, 3);


// ******************** Permalinks ************************************************************
function replace_category_in_permalink($permalink, $post)
{
    // Só faz algo se o post tiver uma categoria e for custom post type
    if (!is_object($post) || $post->post_type === 'post') {
        return $permalink;
    }

    $terms = get_the_terms($post->ID, 'category');
    if ($terms && !is_wp_error($terms)) {
        $category_slug = $terms[0]->slug;
    } else {
        $category_slug = 'sem-categoria';
    }

    return str_replace('%category%', $category_slug, $permalink);
}
add_filter('post_type_link', 'replace_category_in_permalink', 10, 2);

function custom_rewrite_rules_for_all_post_types()
{
    $post_types = get_post_types(['public' => true, '_builtin' => false], 'names');

    foreach ($post_types as $pt) {
        $post_type_slug = $pt;

        // Regra para a página de arquivo do tipo de post
        add_rewrite_rule(
            '^' . $post_type_slug . '/?$',
            'index.php?post_type=' . $post_type_slug,
            'top'
        );

        // Regra para posts individuais com categoria (considerando a estrutura global)
        add_rewrite_rule(
            '^' . $post_type_slug . '/([^/]+)/([^/]+)/?$',
            'index.php?post_type=' . $post_type_slug . '&category_name=$1&name=$2',
            'top'
        );
    }
}
add_action('init', 'custom_rewrite_rules_for_all_post_types');

function custom_rewrite_rules_for_types()
{
    // Regra para /congrega/
    add_rewrite_rule(
        '^congrega/?$',
        'index.php?post_type=congrega',
        'top'
    );

    // Regra para /ci/
    add_rewrite_rule(
        '^ci/?$',
        'index.php?post_type=ci',
        'top'
    );

    // Regra para /dsc/
    add_rewrite_rule(
        '^dsc/?$',
        'index.php?post_type=dsc',
        'top'
    );

    // Regra para /dsi/
    add_rewrite_rule(
        '^dsi/?$',
        'index.php?post_type=dsi',
        'top'
    );

    // Regra para /dtc/
    add_rewrite_rule(
        '^dtc/?$',
        'index.php?post_type=dtc',
        'top'
    );

    // Regra para /cdi/
    add_rewrite_rule(
        '^cdi/?$',
        'index.php?post_type=cdi',
        'top'
    );
}
add_action('init', 'custom_rewrite_rules_for_types');


//Search PDF *************************************************************************************
add_filter('pre_get_posts', function ($query) {
    if ($query->is_search() && $query->is_main_query()) {
        $termo = $query->get('s');

        global $wpdb;
        $tabela = $wpdb->prefix . 'pdf_index';

        $resultados = $wpdb->get_results($wpdb->prepare("
            SELECT arquivo FROM $tabela WHERE texto LIKE %s
        ", '%' . $wpdb->esc_like($termo) . '%'));

        if ($resultados) {
            add_filter('the_content', function ($content) use ($resultados, $termo) {
                $lista = "<h3>Resultados nos PDFs:</h3><ul>";
                foreach ($resultados as $r) {
                    $lista .= "<li><a href='/wp-content/uploads/pdfs/{$r->arquivo}' target='_blank'>{$r->arquivo}</a></li>";
                }
                $lista .= "</ul>";
                return $lista . $content;
            });
        }
    }
    return $query;
});

// Add user-metas ******************************************************************************************************************

/**
 * Adiciona um campo "Membro" (checkboxes) ao perfil do usuário.
 */
function adicionar_campo_membro_perfil_checkbox($user)
{
    $tipos_membro = array(
        'congrega' => 'Congrega',
        'ci' => 'CI',
        'dsc' => 'DSC',
        'dsi' => 'DSI',
        'dtc' => 'DTC',
        'cdi' => 'CDI',
    );
    $membros_usuario = get_user_meta($user->ID, 'membro', true);
    if (!is_array($membros_usuario)) {
        $membros_usuario = array(); // Garante que seja um array mesmo que não haja valores salvos
    }
    ?>

    <br>
    <hr>

    <h3>Informações de <u>Membro</u></h3>

    <table class="form-table">
        <tr>
            <th>Tipos de Membro</th>
            <td>
                <?php foreach ($tipos_membro as $slug => $nome): ?>
                    <label for="membro_<?php echo esc_attr($slug); ?>">
                        <input style="border:1px solid #444;pointer-events: none;opacity: 1 !important;accent-color: #0066cc;cursor: default;" type="checkbox" disabled name="membro[]" id="membro_<?php echo esc_attr($slug); ?>"
                            value="<?php echo esc_attr($slug); ?>" <?php checked(in_array($slug, $membros_usuario)); ?> />
                        <?php echo esc_html($nome); ?>
                    </label><br />
                <?php endforeach; ?>
                <br><span class="description">(seleção automática, fonte: Intranet)</span>
            </td>
        </tr>
    </table>
    <?php
}
add_action('show_user_profile', 'adicionar_campo_membro_perfil_checkbox');
add_action('edit_user_profile', 'adicionar_campo_membro_perfil_checkbox');

function salvar_campo_membro_perfil_checkbox($user_id)
{
    if (!current_user_can('edit_user', $user_id)) {
        return;
    }
    if (isset($_POST['membro']) && is_array($_POST['membro'])) {
        $membros_sanitizados = array_map('sanitize_text_field', $_POST['membro']);
        update_user_meta($user_id, 'membro', $membros_sanitizados);
    } else {
        delete_user_meta($user_id, 'membro'); // Remove a meta se nenhum checkbox estiver selecionado
    }
}
add_action('personal_options_update', 'salvar_campo_membro_perfil_checkbox');
add_action('edit_user_profile_update', 'salvar_campo_membro_perfil_checkbox');


/**
 * Adiciona um campo "Membro Post Privado" (checkboxes) ao perfil do usuário. (quais 'posts privados' o membro pode ler)
 */
function adicionar_campo_membro_post_privado_perfil_checkbox($user)
{
    $tipos_membro_post_privado = array(
        'congrega' => 'Acesso a posts privados do Congrega',
        'ci' => 'Acesso a posts privados do CI',
        'dsc' => 'Acesso a posts privados do DSC',
        'dsi' => 'Acesso a posts privados do DSI',
        'dtc' => 'Acesso a posts privados do DTC',
        'cdi' => 'Acesso a posts privados do CDI',
    );
    $membro_post_privados_usuario = get_user_meta($user->ID, 'membro_post_privado', true);
    if (!is_array($membro_post_privados_usuario)) {
        $membro_post_privados_usuario = array(); // Garante que seja um array mesmo que não haja valores salvos
    }
    ?>

    <br>
    <hr>

    <h3>Informações de <u>Membro de <b>Posts</b> Privados</u></h3>

    <table class="form-table">
        <tr>
            <th><label><?php esc_html_e('Tipos de Membro'); ?></label></th>
            <td>
                <?php foreach ($tipos_membro_post_privado as $slug => $nome): ?>
                    <label for="membro_post_privado_<?php echo esc_attr($slug); ?>">
                        <input style="border:1px solid #444;pointer-events: none;opacity: 1 !important;accent-color: #0066cc;cursor: default;" type="checkbox" disabled name="membro_post_privado[]"
                            id="membro_post_privado_<?php echo esc_attr($slug); ?>" value="<?php echo esc_attr($slug); ?>" <?php checked(in_array($slug, $membro_post_privados_usuario)); ?> />
                        <?php echo esc_html($nome); ?>
                    </label><br />
                <?php endforeach; ?>
                <br><span class="description"><?php esc_html_e('(seleção automática, fonte: Intranet)'); ?></span>
            </td>
        </tr>
    </table>
    <?php
}
add_action('show_user_profile', 'adicionar_campo_membro_post_privado_perfil_checkbox');
add_action('edit_user_profile', 'adicionar_campo_membro_post_privado_perfil_checkbox');

function salvar_campo_membro_post_privado_perfil_checkbox($user_id)
{
    if (!current_user_can('edit_user', $user_id)) {
        return;
    }
    if (isset($_POST['membro_post_privado']) && is_array($_POST['membro_post_privado'])) {
        $membro_post_privados_sanitizados = array_map('sanitize_text_field', $_POST['membro_post_privado']);
        update_user_meta($user_id, 'membro_post_privado', $membro_post_privados_sanitizados);
    } else {
        delete_user_meta($user_id, 'membro_post_privado'); // Remove a meta se nenhum checkbox estiver selecionado
    }
}
add_action('personal_options_update', 'salvar_campo_membro_post_privado_perfil_checkbox');
add_action('edit_user_profile_update', 'salvar_campo_membro_post_privado_perfil_checkbox');



/**
 * Adiciona um campo "Membro Arqvivo Privado" (checkboxes) ao perfil do usuário. (quais 'arquivos privados' o membro pode ler)
 */
function adicionar_campo_membro_arquivo_privado_perfil_checkbox($user)
{
    $tipos_membro_arquivo_privado = array(
        'congrega' => 'Acesso a arquivos privados do Congrega',
        'ci' => 'Acesso a arquivos privados do CI',
        'dsc' => 'Acesso a arquivos privados do DSC',
        'dsi' => 'Acesso a arquivos privados do DSI',
        'dtc' => 'Acesso a arquivos privados do DTC',
        'cdi' => 'Acesso a arquivos privados do CDI',
    );
    $membro_arquivo_privados_usuario = get_user_meta($user->ID, 'membro_arquivo_privado', true);
    if (!is_array($membro_arquivo_privados_usuario)) {
        $membro_arquivo_privados_usuario = array(); // Garante que seja um array mesmo que não haja valores salvos
    }
    ?>

    <br>
    <hr>

    <h3>Informações de <u>Membro de <b>Arquivos</b> Privados</u></h3>

    <table class="form-table">
        <tr>
            <th><label>Tipos de Membro</label></th>
            <td>
                <?php foreach ($tipos_membro_arquivo_privado as $slug => $nome): ?>
                    <label for="membro_arquivo_privado_<?php echo esc_attr($slug); ?>">
                        <input style="border:1px solid #444;pointer-events: none;opacity: 1 !important;accent-color: #0066cc;cursor: default;" type="checkbox" disabled name="membro_arquivo_privado[]"
                            id="membro_arquivo_privado_<?php echo esc_attr($slug); ?>" value="<?php echo esc_attr($slug); ?>"
                            <?php checked(in_array($slug, $membro_arquivo_privados_usuario)); ?> />
                        <?php echo esc_html($nome); ?>
                    </label><br />
                <?php endforeach; ?>
                <br><span class="description"><?php esc_html_e('(seleção automática, fonte: Intranet)'); ?></span>
            </td>
        </tr>
    </table>
    <?php
}
add_action('show_user_profile', 'adicionar_campo_membro_arquivo_privado_perfil_checkbox');
add_action('edit_user_profile', 'adicionar_campo_membro_arquivo_privado_perfil_checkbox');

function salvar_campo_membro_arquivo_privado_perfil_checkbox($user_id)
{
    if (!current_user_can('edit_user', $user_id)) {
        return;
    }
    if (isset($_POST['membro_arquivo_privado']) && is_array($_POST['membro_arquivo_privado'])) {
        $membro_arquivo_privados_sanitizados = array_map('sanitize_text_field', $_POST['membro_arquivo_privado']);
        update_user_meta($user_id, 'membro_arquivo_privado', $membro_arquivo_privados_sanitizados);
    } else {
        delete_user_meta($user_id, 'membro_arquivo_privado'); // Remove a meta se nenhum checkbox estiver selecionado
    }
}
add_action('personal_options_update', 'salvar_campo_membro_arquivo_privado_perfil_checkbox');
add_action('edit_user_profile_update', 'salvar_campo_membro_arquivo_privado_perfil_checkbox');




// ******************************************* Adiciona o campo "Aceite" ao perfil do usuário.
function adicionar_campo_aceite_perfil($user)
{
    $valor_aceite = get_user_meta($user->ID, 'aceite', true);
    ?>

    <br>
    <hr>

    <h3><?php esc_html_e('Termo de Aceite ICODE'); ?></h3>
    <table class="form-table">
        <tr>
            <th>
                <label for="aceite"><strong><?php esc_html_e('Você concorda com todos os termos?'); ?></strong></label>
            </th>
            <td>
                <input type="checkbox" name="aceite" id="aceite" value="1" <?php checked($valor_aceite, '1'); ?> />
            </td>
        </tr>
    </table>
    <?php
}
add_action('show_user_profile', 'adicionar_campo_aceite_perfil');
add_action('edit_user_profile', 'adicionar_campo_aceite_perfil');


function salvar_campo_aceite_perfil($user_id)
{
    if (!current_user_can('edit_user', $user_id)) {
        return;
    }

    $valor_aceite = isset($_POST['aceite']) ? '1' : '0';
    update_user_meta($user_id, 'aceite', $valor_aceite);
}
add_action('personal_options_update', 'salvar_campo_aceite_perfil');
add_action('edit_user_profile_update', 'salvar_campo_aceite_perfil');



// Converter PDF ****************************************************************************
function novoicode_converter_pdf()
{
    if (!isset($_POST['paths']) || !isset($_POST['destino'])) {
        wp_send_json(['sucesso' => false, 'mensagem' => 'Parâmetros ausentes.']);
    }

    $paths = json_decode(stripslashes($_POST['paths']), true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        $paths = is_array($_POST['paths']) ? $_POST['paths'] : (array) $_POST['paths'];
    }

    $paths = array_filter((array) $paths);
    $pdfsParaJuntar = [];

    foreach ($paths as $path) {
        $cleanPath = realpath(trim(stripslashes($path), '"\''));
        if ($cleanPath && file_exists($cleanPath)) {
            $ext = strtolower(pathinfo($cleanPath, PATHINFO_EXTENSION));
            if ($ext === 'doc' || $ext === 'docx') {
                $pdfsParaJuntar[] = '"' . $cleanPath . '"';
            }
        }
    }

    if (empty($pdfsParaJuntar)) {
        wp_send_json(['sucesso' => false, 'mensagem' => 'Nenhum DOC válido encontrado.']);
    }

    $destino = trim(stripslashes($_POST['destino']), '"\'');
    $destPath = dirname($destino);

    if (!file_exists($destPath)) {
        wp_mkdir_p($destPath);
    }

    if (!is_writable($destPath)) {
        wp_send_json(['sucesso' => false, 'mensagem' => 'Diretório de destino não tem permissão de escrita.']);
    }

    $strPDFsParaJuntar = implode(" ", $pdfsParaJuntar);


    // Comando para conversão
    exec("export HOME=/var/www && export XDG_CONFIG_HOME=/var/www/.config && export XDG_CACHE_HOME=/var/www/.cache && soffice --headless --convert-to pdf --outdir $destPath $strPDFsParaJuntar 2>&1", $output, $retorno);

    if ($retorno !== 0) {
        wp_send_json(['sucesso' => false, 'mensagem' => 'Erro ao executar script: ' . implode("\n", $output)]);
    }

    wp_send_json([
        'sucesso' => true,
        'arquivos' => count($pdfsParaJuntar)
    ]);
}
add_action('wp_ajax_novoicode_converter_pdf', 'novoicode_converter_pdf');




// Juntar PDF ****************************************************************************
function novoicode_exportar_pdf()
{
    if (!isset($_POST['paths']) || !isset($_POST['destino'])) {
        wp_send_json(['sucesso' => false, 'mensagem' => 'Parâmetros ausentes.']);
    }

    $paths = json_decode(stripslashes($_POST['paths']), true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        $paths = is_array($_POST['paths']) ? $_POST['paths'] : (array) $_POST['paths'];
    }

    $paths = array_filter((array) $paths);
    $pdfsParaJuntar = [];

    foreach ($paths as $path) {
        $cleanPath = realpath(trim(stripslashes($path), '"\''));
        if ($cleanPath && file_exists($cleanPath)) {
            $ext = strtolower(pathinfo($cleanPath, PATHINFO_EXTENSION));
            if ($ext === 'pdf') {
                $pdfsParaJuntar[] = '"' . $cleanPath . '"';
            }
        }
    }

    if (empty($pdfsParaJuntar)) {
        wp_send_json(['sucesso' => false, 'mensagem' => 'Nenhum PDF válido encontrado.']);
    }

    $destino = trim(stripslashes($_POST['destino']), '"\'');
    $destPath = dirname($destino);

    if (!file_exists($destPath)) {
        wp_mkdir_p($destPath);
    }

    if (!is_writable($destPath)) {
        wp_send_json(['sucesso' => false, 'mensagem' => 'Diretório de destino não tem permissão de escrita.']);
    }

    $destFile = $destino;

    // Se o destino já existir, adiciona ele como o primeiro da fusão
    if (file_exists($destFile)) {
        $pdfsParaJuntar = array_merge(['"' . realpath($destFile) . '"'], $pdfsParaJuntar);
    }

    // Cria um arquivo temporário para saída
    $tempOutput = tempnam(sys_get_temp_dir(), 'pdfmerge_') . '.pdf';
    $destPath = escapeshellarg($tempOutput);

    // Comando Ghostscript para fusão
    $cmd = "gs -dBATCH -dNOPAUSE -q -sDEVICE=pdfwrite -sOutputFile=$destPath " . implode(' ', $pdfsParaJuntar);

    exec($cmd, $output, $retorno);

    if ($retorno !== 0 || !file_exists($tempOutput)) {
        wp_send_json(['sucesso' => false, 'mensagem' => 'Erro ao executar Ghostscript: ' . implode("\n", $output)]);
    }

    // Move o arquivo temporário para o destino, sobrescrevendo
    if (!rename($tempOutput, $destFile)) {
        wp_send_json(['sucesso' => false, 'mensagem' => 'Falha ao mover PDF gerado para o destino.']);
    }

    $relPath = str_replace(ABSPATH, '', $destFile);
    $urlFinal = site_url('/') . str_replace(DIRECTORY_SEPARATOR, '/', $relPath);

    wp_send_json([
        'sucesso' => true,
        'url' => $urlFinal,
        'caminho' => $destFile,
        'arquivos' => count($pdfsParaJuntar)
    ]);
}
add_action('wp_ajax_novoicode_exportar_pdf', 'novoicode_exportar_pdf');




// Indexar PDF ****************************************************************************
use Smalot\PdfParser\Parser;
function novoicode_indexar_pdf()
{

    if (!isset($_POST['arquivo'], $_POST['url'], $_POST['tipo'], $_POST['ano'], $_POST['id'])) {
        wp_send_json_error(['msg' => 'Parâmetros ausentes']);
    }

    // Set maximum execution time to prevent timeouts
    set_time_limit(300); // 5 minutos

    $parser = new Parser();
    $arquivo = sanitize_text_field($_POST['arquivo']);
    $url = esc_url_raw($_POST['url']);
    $tipo = sanitize_text_field($_POST['tipo']);
    $ano = sanitize_text_field($_POST['ano']);
    $id = intval($_POST['id']);

    $path = ABSPATH . "wp-content/uploads/$tipo/$ano/";

    $subdirs = [];

    foreach (scandir($path) as $item) {
        if ($item === '.' || $item === '..')
            continue;

        if (is_dir($path . $item)) {
            $subdirs[] = $item;
        }
    }

    global $wpdb;
    $tabela = $wpdb->prefix . 'pdf_index';

    $sql = $wpdb->prepare(
        "SELECT * FROM $tabela WHERE tipo = %s AND ano = %d",
        $tipo,
        $ano
    );

    $results = $wpdb->get_results($sql);

    $all_subdirs = [];

    foreach ($results as $item) {
        $all_subdirs[] = $item->id_post;
    }

    // Remove duplicatas
    $all_subdirs_unicos = array_unique($all_subdirs);

    // Descobre quais id_post estão no array2 mas não no array1
    $id_post_para_apagar = array_diff($all_subdirs_unicos, $subdirs);

    if (!empty($id_post_para_apagar)) { // Se houver itens para apagar
        // Prepara os placeholders para a cláusula IN
        $placeholders = implode(',', array_fill(0, count($id_post_para_apagar), '%d'));
        $sql = "DELETE FROM $tabela WHERE id_post IN ($placeholders)";
        $wpdb->query($wpdb->prepare($sql, ...$id_post_para_apagar));
    }

    // Busca todos os arquivos indexados
    $arquivos = $wpdb->get_results("SELECT arquivo FROM $tabela where id_post = $id");

    foreach ($arquivos as $item) {
        $caminhoArquivo = $item->arquivo;
        // Se o arquivo não existir mais, remove do banco
        if (!file_exists($caminhoArquivo)) {
            $wpdb->delete($tabela, ['arquivo' => $caminhoArquivo]);
        }
    }

    // Verifica se já foi indexado
    $jaIndexado = $wpdb->get_var(
        $wpdb->prepare("SELECT COUNT(*) FROM $tabela WHERE arquivo = %s", $arquivo)
    );

    if ($jaIndexado > 0) {
        // Verifica se o arquivo ainda existe
        if (!file_exists($arquivo)) {
            // Arquivo foi removido, deleta a indexação
            $wpdb->delete($tabela, ['arquivo' => $arquivo]);
            wp_send_json_success(['msg' => 'Indexação removida, arquivo não existe mais']);
        } else {
            wp_send_json_success(['msg' => 'Já existia']);
        }
    } else {
        // Arquivo não indexado ainda, tenta processar
        if (!file_exists($arquivo)) {
            wp_send_json_error(['msg' => 'Arquivo não encontrado']);
        }

        try {
            $pdf = $parser->parseFile($arquivo);
            $texto = $pdf->getText();
            $texto = substr($texto, 0, 100000); // Limita o tamanho do texto

            $wpdb->insert($tabela, [
                'arquivo' => $arquivo,
                'url' => $url,
                'texto' => $texto,
                'tipo' => $tipo,
                'ano' => $ano,
                'id_post' => $id
            ]);
            wp_send_json_success(['msg' => 'Indexado']);
        } catch (Exception $e) {
            wp_send_json_error(['msg' => 'Erro ao processar PDF: ' . $e->getMessage()]);
        }
    }
}
add_action('wp_ajax_novoicode_indexar_pdf', 'novoicode_indexar_pdf');




// Listar PDF ****************************************************************************
function novoicode_listar_pdfs()
{
    if (!isset($_POST['tipo'], $_POST['ano'])) {
        wp_send_json_error(['msg' => 'Parâmetros ausentes']);
    }

    $tipo = sanitize_text_field($_POST['tipo']);
    $ano = sanitize_text_field($_POST['ano']);
    $base_dir = ABSPATH . "wp-content/uploads/$tipo/$ano";

    if (!file_exists($base_dir)) {
        wp_send_json_error(['msg' => 'Diretório não encontrado']);
    }

    $arquivos = [];
    $urls = [];
    $ids = [];

    $subdirs = scandir($base_dir);
    foreach ($subdirs as $subdir) {
        if ($subdir === '.' || $subdir === '..')
            continue;

        $full_path = $base_dir . '/' . $subdir;
        if (!is_dir($full_path))
            continue;

        $id_post = is_numeric($subdir) ? intval($subdir) : 0;

        $directory = new RecursiveDirectoryIterator($full_path, RecursiveDirectoryIterator::SKIP_DOTS);
        $filter = new RecursiveCallbackFilterIterator($directory, function ($fileInfo) {
            return !($fileInfo->isDir() && $fileInfo->getFilename() === 'privado');
        });
        $iterator = new RecursiveIteratorIterator($filter);

        foreach ($iterator as $arquivo) {
            if (pathinfo($arquivo, PATHINFO_EXTENSION) === 'pdf') {
                $arquivos[] = (string) $arquivo;
                $subpath = str_replace(ABSPATH, '', (string) $arquivo);
                $url_pdf = '/' . str_replace('\\', '/', $subpath);
                $urls[] = esc_url($url_pdf);
                $ids[] = $id_post;
            }
        }
    }

    wp_send_json_success([
        'arquivos' => $arquivos,
        'urls' => $urls,
        'ids' => $ids,
        'total' => count($arquivos),
    ]);
}
add_action('wp_ajax_novoicode_listar_pdfs', 'novoicode_listar_pdfs');




// **************************************************************FIM ******************************************
function adicionar_linha_espaco($user)
{
    ?>
    <br><br>
    <?php
}
add_action('show_user_profile', 'adicionar_linha_espaco');
add_action('edit_user_profile', 'adicionar_linha_espaco');


// **************************** LOGOUT ***********************************************************************
add_action('init', 'icode_check_logout');
function icode_check_logout()
{
    if (isset($_GET['icode_logout']) && $_GET['icode_logout'] === '1') {
        icode_logout();
    }
}

function icode_logout()
{
    // Iniciar sessão se necessário
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    // Limpar variáveis de sessão
    unset($_SESSION['ldap_login_redirect']);
    session_destroy();

    // Realizar logout do WP diretamente (sem redirecionar para wp_logout_url)
    wp_logout();

    // Redirecionar para a página inicial ou outra URL
    wp_redirect(home_url());
    exit;
}