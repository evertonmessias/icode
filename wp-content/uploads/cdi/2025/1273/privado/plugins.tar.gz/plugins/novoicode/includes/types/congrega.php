<?php
//Arquivo: wp-content/plugins/novoicode/includes/types/congrega.php
function create_custom_post_type_congrega()
{
	$labels = [
		'name' => _x('Congrega', 'post type general name'),
		'singular_name' => _x('Congrega', 'post type singular name'),
		'add_new' => _x('Adicionar', 'Congrega'),
		'add_new_item' => __('Adicionar novo post Congrega'),
		'edit_item' => __('Editar post Congrega'),
		'new_item' => __('Novo Congrega'),
		'view_item' => __('Ver Congrega'),
		'search_items' => __('Buscar Congrega'),
		'not_found' => __('Nada encontrado'),
		'not_found_in_trash' => __('Nada na lixeira'),
		'parent_item_colon' => ''
	];
	$args = [
		'labels' => $labels,
		'supports' => ['title', 'editor','revisions'],
		'hierarchical' => false,
		'taxonomies' => ['category'],
		'public' => true,
		'show_ui' => true,
		'show_in_menu' => false,
		'query_var' => true,
		'menu_position' => 0,
		'show_in_admin_bar' => true,
		'rewrite' => ['slug' => 'congrega/%category%', 'with_front' => false],
		'show_in_nav_menus' => true,
		'can_export' => true,
		'menu_icon' => 'dashicons-groups',
		'has_archive' => true,
		'exclude_from_search' => false,
		'publicly_queryable' => true,
		'capability_type' => ['post', 'congrega'],
		'map_meta_cap' => true,
	];
	register_post_type('congrega', $args);
}
add_action('init', 'create_custom_post_type_congrega');

// Submenu no admin
function type_congrega()
{
	add_submenu_page('icode', 'Congrega', 'Congrega', 'edit_posts', 'edit.php?post_type=congrega');
}
add_action('admin_menu', 'type_congrega');

// Permissões
function role_caps_congrega()
{
	$roles = array('editor', 'administrator');
	foreach ($roles as $the_role) {
		$role = get_role($the_role);
		if ($role) {
			$role->add_cap('read');
			$role->add_cap('read_congrega');
			$role->add_cap('read_private_congrega');
			$role->add_cap('edit_congrega');
			$role->add_cap('edit_others_congrega');
			$role->add_cap('edit_published_congrega');
			$role->add_cap('publish_congrega');
			$role->add_cap('delete_others_congrega');
			$role->add_cap('delete_private_congrega');
			$role->add_cap('delete_published_congrega');
		}
	}
}
add_action('admin_init', 'role_caps_congrega', 999);

//******************************************** POST META CONGREGA **************************************************** */

// Privado? ******************************************
function field_box_congrega_privado()
{
	add_meta_box('congrega_privado_id', 'Reunião Privada', 'field_congrega_privado', 'congrega', 'side');
}
add_action('add_meta_boxes', 'field_box_congrega_privado');

function field_congrega_privado($post)
{
	$value = get_post_meta($post->ID, 'congrega_privado', true);
	?>
	<label>
		<input type="checkbox" name='congrega_privado' value="1" <?php checked($value, '1'); ?>>
		Marcar como reunião privada
	</label>
	<?php
}

// Data **********************************************

function field_box_congrega_date()
{
	add_meta_box('congrega_date_id', 'Data da Reunião', 'field_congrega_date', 'congrega', 'advanced');
}
add_action('add_meta_boxes', 'field_box_congrega_date');

function field_congrega_date($post)
{
	$value = get_post_meta($post->ID, 'congrega_date', true);
	?>
	<i id="scrollToTop" class='bx bxs-up-arrow-square'></i>
	<input type="datetime-local" name="congrega_date" value="<?php echo $value; ?>">
	<?php
}


// Membros **********************************************

function field_box_congrega_member()
{
	add_meta_box('congrega_member_id', 'Membros <small>( preenchimento automático via Intranet )&emsp;</small>', 'field_congrega_member', 'congrega', 'advanced');
}
add_action('add_meta_boxes', 'field_box_congrega_member');

function field_congrega_member($post)
{
	$site = 'congrega';
	if (get_post_meta($post->ID, 'congrega_member', true) == "") {
		$value = do_shortcode('[icapi tipo="composicao_' . $site . '" saida="html/?modo=short"]');
	} else {
		$value = get_post_meta($post->ID, 'congrega_member', true);
	}

	$args = array(
		//'textarea_rows' => 20,
		'textarea_name' => 'congrega_member',
		'media_buttons' => false,
		'quicktags' => false,
		'tinymce' => array(
			'toolbar2' => FALSE,
			'media_buttons' => false,
		),
	);

	wp_editor($value, 'field_congrega_member_id', $args);
	?>

	<?php
}

//* MOVE  ******************************************************************************************* */


// Move all "advanced" metaboxes after title
add_action('edit_form_after_title', function () {
	global $post, $wp_meta_boxes;
	do_meta_boxes(get_current_screen(), 'advanced', $post);
	unset($wp_meta_boxes[get_post_type($post)]['advanced']);
});

// Move all "default" metaboxes after editor
add_action('edit_form_after_editor', function () {
	global $post, $wp_meta_boxes;
	do_meta_boxes(get_current_screen(), 'default', $post);
	unset($wp_meta_boxes[get_post_type($post)]['default']);
});


/* SAVE ALL ******************************************************************************************* */

add_action('save_post', 'save_postmeta_congrega');

function save_postmeta_congrega($post_id)
{
	// Impede execução em autosave, revisions ou sem permissão
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
	if (is_int(wp_is_post_revision($post_id))) return;
	if (!current_user_can('edit_post', $post_id)) return;

	// Garante que é do tipo correto
	if (get_post_type($post_id) !== 'congrega') return;

	// Salva "privado"
	$privado = isset($_POST['congrega_privado']) ? '1' : '0';
	update_post_meta($post_id, 'congrega_privado', $privado);

	// Salva data
	if (isset($_POST['congrega_date'])) {
		$congrega_date = sanitize_text_field($_POST['congrega_date']);
		update_post_meta($post_id, 'congrega_date', $congrega_date);
	}

	// Salva membros
	if (isset($_POST['congrega_member'])) {
		$congrega_member = wp_kses_post($_POST['congrega_member']);
		update_post_meta($post_id, 'congrega_member', $congrega_member);
	}
}
