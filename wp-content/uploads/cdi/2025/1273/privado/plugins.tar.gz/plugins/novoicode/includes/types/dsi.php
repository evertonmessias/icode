<?php
//Arquivo: wp-content/plugins/novoicode/includes/types/dsi.php
function create_custom_post_type_dsi()
{
	$labels = [
		'name' => _x('DSI', 'post type general name'),
		'singular_name' => _x('DSI', 'post type singular name'),
		'add_new' => _x('Adicionar', 'DSI'),
		'add_new_item' => __('Adicionar novo post DSI'),
		'edit_item' => __('Editar post DSI'),
		'new_item' => __('Novo DSI'),
		'view_item' => __('Ver DSI'),
		'search_items' => __('Buscar DSI'),
		'not_found' =>  __('Nada encontrado'),
		'not_found_in_trash' => __('Nada na lixeira'),
		'parent_item_colon' => ''
	];
	$args = [
		'labels'				=> $labels,
		'supports'              => ['title', 'editor','revisions'],
		'hierarchical'          => false,
        'taxonomies'            => ['category'],
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => false,
		'query_var' 			=> true,
		'menu_position'         => 0,
		'show_in_admin_bar'     => true,
		'rewrite'               => ['slug' => 'dsi/%category%','with_front' => false],
		'show_in_nav_menus'     => true,
		'can_export'			=> true,
		'menu_icon'             => 'dashicons-groups',
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'     	=> ['post', 'dsi'],
		'map_meta_cap'        => true,
	];
	register_post_type('dsi', $args);
}
add_action('init', 'create_custom_post_type_dsi');

// Submenu no admin
function type_dsi()
{
	add_submenu_page('icode', 'DSI', 'DSI', 'edit_posts', 'edit.php?post_type=dsi');
}
add_action('admin_menu', 'type_dsi');

// Permissões
function role_caps_dsi()
{
	$roles = array('editor', 'administrator');
	foreach ($roles as $the_role) {
		$role = get_role($the_role);
		if ($role) {
			$role->add_cap('read');
			$role->add_cap('read_dsi');
			$role->add_cap('read_private_dsi');
			$role->add_cap('edit_dsi');
			$role->add_cap('edit_others_dsi');
			$role->add_cap('edit_published_dsi');
			$role->add_cap('publish_dsi');
			$role->add_cap('delete_others_dsi');
			$role->add_cap('delete_private_dsi');
			$role->add_cap('delete_published_dsi');
		}
	}
}
add_action('admin_init', 'role_caps_dsi', 999);

//******************************************** POST META dsi **************************************************** */

// Privado? ******************************************
function field_box_dsi_privado()
{
	add_meta_box('dsi_privado_id', 'Reunião Privada', 'field_dsi_privado', 'dsi', 'side');
}
add_action('add_meta_boxes', 'field_box_dsi_privado');

function field_dsi_privado($post)
{
	$value = get_post_meta($post->ID, 'dsi_privado', true);
	?>
	<label>
		<input type="checkbox" name='dsi_privado' value="1" <?php checked($value, '1'); ?>>
		Marcar como reunião privada
	</label>
	<?php
}

// Data **********************************************

function field_box_dsi_date()
{
    add_meta_box('dsi_date_id', 'Data da Reunião', 'field_dsi_date', 'dsi', 'advanced');
}
add_action('add_meta_boxes', 'field_box_dsi_date');

function field_dsi_date($post)
{
    $value = get_post_meta($post->ID, 'dsi_date', true);
?>
    <i id="scrollToTop" class='bx bxs-up-arrow-square'></i>
    <input type="datetime-local" name="dsi_date" value="<?php echo $value; ?>">
<?php
}


// Membros **********************************************

function field_box_dsi_member()
{
        add_meta_box('dsi_member_id', 'Membros <small>( preenchimento automático via Intranet )&emsp;</small>', 'field_dsi_member', 'dsi', 'advanced');
}
add_action('add_meta_boxes', 'field_box_dsi_member');

function field_dsi_member($post)
{
    $site = 'dsi';
    if (get_post_meta($post->ID, 'dsi_member', true) == "") {
        $value = do_shortcode('[icapi tipo="composicao_' . $site . '" saida="html/?modo=short"]');
    } else {
        $value = get_post_meta($post->ID, 'dsi_member', true);
    }

    $args = array(
        //'textarea_rows' => 20,
        'textarea_name' => 'dsi_member',
        'media_buttons' => false,
        'quicktags'     => false,
        'tinymce'       => array(
            'toolbar2' => FALSE,
            'media_buttons' => false,
        ),
    );

    wp_editor($value, 'field_dsi_member_id', $args);
?>

<?php
}

//* MOVE  ******************************************************************************************* */


// Move all "advanced" metaboxes after title
add_action('edit_form_after_title', function () {
    global $post, $wp_meta_boxes;
    do_meta_boxes(get_current_screen(), 'advanced', $post);
    unset($wp_meta_boxes[get_post_type($post)]['advanced']);
});

// Move all "default" metaboxes after editor
add_action('edit_form_after_editor', function () {
    global $post, $wp_meta_boxes;
    do_meta_boxes(get_current_screen(), 'default', $post);
    unset($wp_meta_boxes[get_post_type($post)]['default']);
});


/* SAVE ALL ******************************************************************************************* */

add_action('save_post', 'save_postmeta_dsi');

function save_postmeta_dsi($post_id)
{
	// Impede execução em autosave, revisions ou sem permissão
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
	if (is_int(wp_is_post_revision($post_id))) return;
	if (!current_user_can('edit_post', $post_id)) return;

	// Garante que é do tipo correto
	if (get_post_type($post_id) !== 'dsi') return;

	// Salva "privado"
	$privado = isset($_POST['dsi_privado']) ? '1' : '0';
	update_post_meta($post_id, 'dsi_privado', $privado);

	// Salva data
	if (isset($_POST['dsi_date'])) {
		$dsi_date = sanitize_text_field($_POST['dsi_date']);
		update_post_meta($post_id, 'dsi_date', $dsi_date);
	}

	// Salva membros
	if (isset($_POST['dsi_member'])) {
		$dsi_member = wp_kses_post($_POST['dsi_member']);
		update_post_meta($post_id, 'dsi_member', $dsi_member);
	}
}