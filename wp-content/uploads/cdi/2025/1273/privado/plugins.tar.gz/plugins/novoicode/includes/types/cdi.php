<?php
//Arquivo: wp-content/plugins/novoicode/includes/types/cdi.php
function create_custom_post_type_cdi()
{
	$labels = [
		'name' => _x('cdi', 'post type general name'),
		'singular_name' => _x('CDI', 'post type singular name'),
		'add_new' => _x('Adicionar', 'CDI'),
		'add_new_item' => __('Adicionar novo post CDI'),
		'edit_item' => __('Editar post CDI'),
		'new_item' => __('Novo CDI'),
		'view_item' => __('Ver CDI'),
		'search_items' => __('Buscar CDI'),
		'not_found' =>  __('Nada encontrado'),
		'not_found_in_trash' => __('Nada na lixeira'),
		'parent_item_colon' => ''
	];
	$args = [
		'labels'				=> $labels,
		'supports'              => ['title', 'editor','revisions'],
		'hierarchical'          => false,
        'taxonomies'            => ['category'],
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => false,
		'query_var' 			=> true,
		'menu_position'         => 0,
		'show_in_admin_bar'     => true,
		'rewrite'               => ['slug' => 'cdi/%category%','with_front' => false],
		'show_in_nav_menus'     => true,
		'can_export'			=> true,
		'menu_icon'             => 'dashicons-groups',
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'     	=> ['post', 'cdi'],
		'map_meta_cap'        => true,
	];
	register_post_type('cdi', $args);
}
add_action('init', 'create_custom_post_type_cdi');

// Submenu no admin
function type_cdi()
{
	add_submenu_page('icode', 'CDI', 'CDI', 'edit_posts', 'edit.php?post_type=cdi');
}
add_action('admin_menu', 'type_cdi');

// Permissões
function role_caps_cdi()
{
	$roles = array('editor', 'administrator');
	foreach ($roles as $the_role) {
		$role = get_role($the_role);
		if ($role) {
			$role->add_cap('read');
			$role->add_cap('read_cdi');
			$role->add_cap('read_private_cdi');
			$role->add_cap('edit_cdi');
			$role->add_cap('edit_others_cdi');
			$role->add_cap('edit_published_cdi');
			$role->add_cap('publish_cdi');
			$role->add_cap('delete_others_cdi');
			$role->add_cap('delete_private_cdi');
			$role->add_cap('delete_published_cdi');
		}
	}
}
add_action('admin_init', 'role_caps_cdi', 999);

//******************************************** POST META CDI **************************************************** */

// Privado? ******************************************
function field_box_cdi_privado()
{
	add_meta_box('cdi_privado_id', 'Reunião Privada', 'field_cdi_privado', 'cdi', 'side');
}
add_action('add_meta_boxes', 'field_box_cdi_privado');

function field_cdi_privado($post)
{
	$value = get_post_meta($post->ID, 'cdi_privado', true);
	?>
	<label>
		<input type="checkbox" name='cdi_privado' value="1" <?php checked($value, '1'); ?>>
		Marcar como reunião privada
	</label>
	<?php
}

// Data **********************************************

function field_box_cdi_date()
{
    add_meta_box('cdi_date_id', 'Data da Reunião', 'field_cdi_date', 'cdi', 'advanced');
}
add_action('add_meta_boxes', 'field_box_cdi_date');

function field_cdi_date($post)
{
    $value = get_post_meta($post->ID, 'cdi_date', true);
?>
    <i id="scrollToTop" class='bx bxs-up-arrow-square'></i>
    <input type="datetime-local" name="cdi_date" value="<?php echo $value; ?>">
<?php
}


// Membros **********************************************

function field_box_cdi_member()
{
        add_meta_box('cdi_member_id', 'Membros <small>( preenchimento automático via Intranet )&emsp;</small>', 'field_cdi_member', 'cdi', 'advanced');
}
add_action('add_meta_boxes', 'field_box_cdi_member');

function field_cdi_member($post)
{
    $site = 'cdi';
    if (get_post_meta($post->ID, 'cdi_member', true) == "") {
        $value = do_shortcode('[icapi tipo="composicao_' . $site . '" saida="html/?modo=short"]');
    } else {
        $value = get_post_meta($post->ID, 'cdi_member', true);
    }

    $args = array(
        //'textarea_rows' => 20,
        'textarea_name' => 'cdi_member',
        'media_buttons' => false,
        'quicktags'     => false,
        'tinymce'       => array(
            'toolbar2' => FALSE,
            'media_buttons' => false,
        ),
    );

    wp_editor($value, 'field_cdi_member_id', $args);
?>

<?php
}


//* MOVE  ******************************************************************************************* */


// Move all "advanced" metaboxes after title
add_action('edit_form_after_title', function () {
    global $post, $wp_meta_boxes;
    do_meta_boxes(get_current_screen(), 'advanced', $post);
    unset($wp_meta_boxes[get_post_type($post)]['advanced']);
});

// Move all "default" metaboxes after editor
add_action('edit_form_after_editor', function () {
    global $post, $wp_meta_boxes;
    do_meta_boxes(get_current_screen(), 'default', $post);
    unset($wp_meta_boxes[get_post_type($post)]['default']);
});


/* SAVE ALL ******************************************************************************************* */

/* SAVE ALL ******************************************************************************************* */

add_action('save_post', 'save_postmeta_cdi');

function save_postmeta_cdi($post_id)
{
	// Impede execução em autosave, revisions ou sem permissão
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
	if (is_int(wp_is_post_revision($post_id))) return;
	if (!current_user_can('edit_post', $post_id)) return;

	// Garante que é do tipo correto
	if (get_post_type($post_id) !== 'cdi') return;

	// Salva "privado"
	$privado = isset($_POST['cdi_privado']) ? '1' : '0';
	update_post_meta($post_id, 'cdi_privado', $privado);

	// Salva data
	if (isset($_POST['cdi_date'])) {
		$cdi_date = sanitize_text_field($_POST['cdi_date']);
		update_post_meta($post_id, 'cdi_date', $cdi_date);
	}

	// Salva membros
	if (isset($_POST['cdi_member'])) {
		$cdi_member = wp_kses_post($_POST['cdi_member']);
		update_post_meta($post_id, 'cdi_member', $cdi_member);
	}
}