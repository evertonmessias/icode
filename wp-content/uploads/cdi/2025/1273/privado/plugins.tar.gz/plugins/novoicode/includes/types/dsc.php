<?php
//Arquivo: wp-content/plugins/novoicode/includes/types/dsc.php
function create_custom_post_type_dsc()
{
	$labels = [
		'name' => _x('DSC', 'post type general name'),
		'singular_name' => _x('DSC', 'post type singular name'),
		'add_new' => _x('Adicionar', 'DSC'),
		'add_new_item' => __('Adicionar novo post DSC'),
		'edit_item' => __('Editar post DSC'),
		'new_item' => __('Novo DSC'),
		'view_item' => __('Ver DSC'),
		'search_items' => __('Buscar DSC'),
		'not_found' =>  __('Nada encontrado'),
		'not_found_in_trash' => __('Nada na lixeira'),
		'parent_item_colon' => ''
	];
	$args = [
		'labels'				=> $labels,
		'supports'              => ['title', 'editor','revisions'],
		'hierarchical'          => false,
        'taxonomies'            => ['category'],
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => false,
		'query_var' 			=> true,
		'menu_position'         => 0,
		'show_in_admin_bar'     => true,
		'rewrite'               => ['slug' => 'dsc/%category%','with_front' => false],
		'show_in_nav_menus'     => true,
		'can_export'			=> true,
		'menu_icon'             => 'dashicons-groups',
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'     	=> ['post', 'dsc'],
		'map_meta_cap'        => true,
	];
	register_post_type('dsc', $args);
}
add_action('init', 'create_custom_post_type_dsc');

// Submenu no admin
function type_dsc()
{
	add_submenu_page('icode', 'DSC', 'DSC', 'edit_posts', 'edit.php?post_type=dsc');
}
add_action('admin_menu', 'type_dsc');

// Permissões
function role_caps_dsc()
{
	$roles = array('editor', 'administrator');
	foreach ($roles as $the_role) {
		$role = get_role($the_role);
		if ($role) {
			$role->add_cap('read');
			$role->add_cap('read_dsc');
			$role->add_cap('read_private_dsc');
			$role->add_cap('edit_dsc');
			$role->add_cap('edit_others_dsc');
			$role->add_cap('edit_published_dsc');
			$role->add_cap('publish_dsc');
			$role->add_cap('delete_others_dsc');
			$role->add_cap('delete_private_dsc');
			$role->add_cap('delete_published_dsc');
		}
	}
}
add_action('admin_init', 'role_caps_dsc', 999);

//******************************************** POST META dsc **************************************************** */

// Privado? ******************************************
function field_box_dsc_privado()
{
	add_meta_box('dsc_privado_id', 'Reunião Privada', 'field_dsc_privado', 'dsc', 'side');
}
add_action('add_meta_boxes', 'field_box_dsc_privado');

function field_dsc_privado($post)
{
	$value = get_post_meta($post->ID, 'dsc_privado', true);
	?>
	<label>
		<input type="checkbox" name='dsc_privado' value="1" <?php checked($value, '1'); ?>>
		Marcar como reunião privada
	</label>
	<?php
}

// Data **********************************************

function field_box_dsc_date()
{
    add_meta_box('dsc_date_id', 'Data da Reunião', 'field_dsc_date', 'dsc', 'advanced');
}
add_action('add_meta_boxes', 'field_box_dsc_date');

function field_dsc_date($post)
{
    $value = get_post_meta($post->ID, 'dsc_date', true);
?>
    <i id="scrollToTop" class='bx bxs-up-arrow-square'></i>
    <input type="datetime-local" name="dsc_date" value="<?php echo $value; ?>">
<?php
}


// Membros **********************************************

function field_box_dsc_member()
{
        add_meta_box('dsc_member_id', 'Membros <small>( preenchimento automático via Intranet )&emsp;</small>', 'field_dsc_member', 'dsc', 'advanced');
}
add_action('add_meta_boxes', 'field_box_dsc_member');

function field_dsc_member($post)
{
    $site = 'dsc';
    if (get_post_meta($post->ID, 'dsc_member', true) == "") {
        $value = do_shortcode('[icapi tipo="composicao_' . $site . '" saida="html/?modo=short"]');
    } else {
        $value = get_post_meta($post->ID, 'dsc_member', true);
    }

    $args = array(
        //'textarea_rows' => 20,
        'textarea_name' => 'dsc_member',
        'media_buttons' => false,
        'quicktags'     => false,
        'tinymce'       => array(
            'toolbar2' => FALSE,
            'media_buttons' => false,
        ),
    );

    wp_editor($value, 'field_dsc_member_id', $args);
?>

<?php
}


//* MOVE  ******************************************************************************************* */


// Move all "advanced" metaboxes after title
add_action('edit_form_after_title', function () {
    global $post, $wp_meta_boxes;
    do_meta_boxes(get_current_screen(), 'advanced', $post);
    unset($wp_meta_boxes[get_post_type($post)]['advanced']);
});

// Move all "default" metaboxes after editor
add_action('edit_form_after_editor', function () {
    global $post, $wp_meta_boxes;
    do_meta_boxes(get_current_screen(), 'default', $post);
    unset($wp_meta_boxes[get_post_type($post)]['default']);
});


/* SAVE ALL ******************************************************************************************* */

add_action('save_post', 'save_postmeta_dsc');

function save_postmeta_dsc($post_id)
{
	// Impede execução em autosave, revisions ou sem permissão
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
	if (is_int(wp_is_post_revision($post_id))) return;
	if (!current_user_can('edit_post', $post_id)) return;

	// Garante que é do tipo correto
	if (get_post_type($post_id) !== 'dsc') return;

	// Salva "privado"
	$privado = isset($_POST['dsc_privado']) ? '1' : '0';
	update_post_meta($post_id, 'dsc_privado', $privado);

	// Salva data
	if (isset($_POST['dsc_date'])) {
		$dsc_date = sanitize_text_field($_POST['dsc_date']);
		update_post_meta($post_id, 'dsc_date', $dsc_date);
	}

	// Salva membros
	if (isset($_POST['dsc_member'])) {
		$dsc_member = wp_kses_post($_POST['dsc_member']);
		update_post_meta($post_id, 'dsc_member', $dsc_member);
	}
}