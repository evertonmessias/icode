<?php

/**
 * Plugin Name: Novo ICODE
 * Plugin URI: https://ic.unicamp.br/~everton
 * Description: Plugin Novo ICODE
 * Author: EvM.
 * Version: 1.0
 * Text Domain: Novo ICODE
 * Plugin Novo ICODE
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

require_once plugin_dir_path(__FILE__) . 'includes/pdfparser/vendor/autoload.php';

// ***************** Add DB
function add_db_acessos()
{
    global $wpdb;

    $charset_collate = $wpdb->get_charset_collate();

    $table_name1 = $wpdb->prefix . 'acessos';
    $sql1 = "CREATE TABLE $table_name1 (
        id INT AUTO_INCREMENT PRIMARY KEY,
        `user` text NOT NULL,
        `ipadress` text NOT NULL,
        `url` text NOT NULL,
        `time` datetime DEFAULT '0000-00-00 00:00:00' NOT NULL
    ) $charset_collate;";
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name1'") != $table_name1) {
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql1);
    }

    $table_name2 = $wpdb->prefix . 'pdf_index';
    $sql2 = "CREATE TABLE $table_name2 (
        id INT AUTO_INCREMENT PRIMARY KEY,
        arquivo VARCHAR(255) NOT NULL,
        `url` VARCHAR(255) NOT NULL,
        texto LONGTEXT NOT NULL,
        tipo VARCHAR(10) NOT NULL,
        ano INT(4) NOT NULL,
        id_post INT(10) NOT NULL,
        INDEX(arquivo)
    ) $charset_collate;";
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name2'") != $table_name2) {
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql2);
    }

    // Remove o papel de Autor
    if (get_role('author')) {
        remove_role('author');
    }

    // Remove o papel de Colaborador
    if (get_role('contributor')) {
        remove_role('contributor');
    }

    flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'add_db_acessos');


// DEACTIVATE *************************************************
function deactivate()
{
    flush_rewrite_rules();
}
register_deactivation_hook(__FILE__, 'deactivate');


// FUNCTIONS ************************************************
include ABSPATH . '/wp-content/plugins/novoicode/includes/functions.php';

// SETTINGS ************************************************
include ABSPATH . '/wp-content/plugins/novoicode/includes/settings.php';

// TYPES ************************************************
include ABSPATH . '/wp-content/plugins/novoicode/includes/types/cdi.php';
include ABSPATH . '/wp-content/plugins/novoicode/includes/types/ci.php';
include ABSPATH . '/wp-content/plugins/novoicode/includes/types/congrega.php';
include ABSPATH . '/wp-content/plugins/novoicode/includes/types/dsc.php';
include ABSPATH . '/wp-content/plugins/novoicode/includes/types/dsi.php';
include ABSPATH . '/wp-content/plugins/novoicode/includes/types/dtc.php';
