<!-- Arquivo: wp-content/plugins/novoicode/includes/pdfparser.php -->
<div class="container">
    <div class="row">
        <div class="col-lg-12"><br><br>
            <h3>Indexar PDFs</h3>
            <form method="post" class="form-pdfparser">
                <br>

                <label class="form-label">Tipo de Post:</label>
                <select name="tipo" class="form-control">
                    <?php
                    $args = array('public' => true);
                    $post_types = get_post_types($args, 'objects');
                    $excluir = array('post', 'page', 'attachment');
                    foreach ($post_types as $post_type) {
                        if (in_array($post_type->name, $excluir))
                            continue;
                        echo '<option value="' . esc_attr($post_type->name) . '">' . esc_html($post_type->label) . '</option>';
                    }
                    ?>
                </select>
                <br>

                <label class="form-label">Ano:</label>
                <select name="ano" class="form-control">
                    <?php
                    $ano_atual = date('Y');
                    for ($ano = $ano_atual; $ano >= 2008; $ano--) {
                        echo '<option value="' . $ano . '">' . $ano . '</option>';
                    }
                    ?>
                </select>
                <br><br>

                <button type="submit" name="indexar_pdfs" class="button button-primary">Indexar</button>
            </form>
            <br>

            <?php
            if (isset($_POST['indexar_pdfs'])) {
                $tipo = sanitize_text_field($_POST['tipo']);
                $ano = sanitize_text_field($_POST['ano']);
                $base_dir = ABSPATH . "wp-content/uploads/$tipo/$ano";

                if (!file_exists($base_dir)) {
                    echo '<div class="error"><p>Diretório não encontrado: ' . esc_html($base_dir) . '</p></div>';
                    return;
                }

                $arquivos = [];
                $urls = [];
                $ids = [];

                // Scan the year directory
                $subdirs = scandir($base_dir);
                foreach ($subdirs as $subdir) {
                    if ($subdir === '.' || $subdir === '..')
                        continue;

                    $full_path = $base_dir . '/' . $subdir;
                    if (!is_dir($full_path))
                        continue;

                    // Determine ID based on subdirectory name
                    $id_post = is_numeric($subdir) ? intval($subdir) : 0;

                    $directory = new RecursiveDirectoryIterator($full_path, RecursiveDirectoryIterator::SKIP_DOTS);
                    $filter = new RecursiveCallbackFilterIterator($directory, function ($fileInfo, $key, $iterator) {
                        // Ignora o diretório 'privado'
                        if ($fileInfo->isDir() && $fileInfo->getFilename() === 'privado') {
                            return false;
                        }
                        return true;
                    });
                    $iterator = new RecursiveIteratorIterator($filter);

                    foreach ($iterator as $arquivo) {
                        if (pathinfo($arquivo, PATHINFO_EXTENSION) === 'pdf') {
                            $arquivos[] = (string) $arquivo;
                            $subpath = str_replace(ABSPATH, '', (string) $arquivo);
                            $url_pdf = '/' . str_replace('\\', '/', $subpath);
                            $urls[] = esc_url($url_pdf);
                            $ids[] = $id_post;
                        }
                    }

                }

                if (empty($arquivos)) {
                    echo '<div class="error"><p>Nenhum PDF encontrado no diretório: ' . esc_html($base_dir) . '</p></div>';
                    return;
                }

                echo '<div id="progresso-box">';
                echo '<p><b>Indexando Diretório</b>: ' . esc_html($base_dir) . '</p>';
                echo '<p>Total de PDFs: ' . count($arquivos) . '</p>';
                echo '<div id="barra" style="background:#eee;width:100%;height:20px;"><div id="progresso" style="background:green;width:0%;height:20px;"></div></div>';
                echo '<div id="status"></div>';
                echo '</div>';

                echo '<script>
                const arquivos = ' . json_encode($arquivos) . ';
                const urls = ' . json_encode($urls) . ';
                const ids = ' . json_encode($ids) . ';
                const tipo = ' . json_encode($tipo) . ';
                const ano = ' . json_encode($ano) . ';
                const total = arquivos.length;
                let index = 0;

                async function indexarProximo() {
                    if (index >= total) {
                        document.getElementById("status").innerHTML = "<strong>Indexação concluída!</strong>";
                        return;
                    }

                    const arquivoAtual = arquivos[index];
                    const urlAtual = urls[index];
                    const idAtual = ids[index];

                    const porc = Math.round(((index + 1) / total) * 100);
                    document.getElementById("progresso").style.width = porc + "%";
                    document.getElementById("status").innerHTML = "Indexando: " + arquivoAtual + " (" + (index + 1) + "/" + total + ")";

                    try {
                        const formData = new URLSearchParams({
                            action: "novoicode_indexar_pdf",
                            arquivo: arquivoAtual,
                            url: urlAtual,
                            tipo: tipo,
                            ano: ano,
                            id: idAtual
                        });

                        const response = await fetch("' . esc_url_raw(admin_url("admin-ajax.php")) . '", {
                            method: "POST",
                            body: formData
                        });

                        if (!response.ok) throw new Error("Erro na requisição");

                        await response.json();
                    } catch (error) {
                        console.error("Erro ao indexar, pulando arquivo:", error);
                        document.getElementById("status").innerHTML += " <strong>(Pulado devido a erro)</strong>";
                    } finally {
                        index++;
                        setTimeout(indexarProximo, 100);
                    }
                }

                indexarProximo();
                </script>';

            }
            ?>
        </div>
    </div>
</div>