<?php

// Arquivo: wp-content/plugins/novoicode/includes/settings.php

// Settings *************************************************
function portal_page_html()
{ ?>
    <div class="container mt-5 settings-novoicode">
        <h3 class="mb-4">Configurações</h3>
        <hr>
        <form method="post" action="options.php">
            <?php settings_fields('portal_option_grupo'); ?>

            <!-- Nome do Site ********************************** -->
            <br>
            <div class="mb-3">
                <label for="portal_input_0" class="form-label">
                    <h5>Nome do Site:</h5>
                </label>
                <input type="text" id="portal_input_0" name="portal_input_0" class="form-control"
                    value="<?php echo esc_attr(get_option('portal_input_0')); ?>" />
            </div><br>

            <!-- Logo *************************************** -->
            <hr><br>
            <?php $image = get_option('portal_input_1'); ?>
            <div class="mb-3">
                <h5 class="form-label">Logo:</h5>
                <table class="table table-borderless">
                    <tr>
                        <td><a href="#" onclick="upload_image(1,2);"
                                class="btn btn-secondary"><?php _e('Upload Image'); ?></a></td>
                        <td><input type="text" name="portal_input_1" id="portal_input_1" class="form-control"
                                value="<?php echo esc_attr($image); ?>" /></td>
                        <td class="text-center"><a href="<?php echo esc_url($image); ?>" target="_blank"><img
                                    style="height:30px" id="preview_portal_input_1" alt="preview" title="preview"
                                    src="<?php echo esc_url($image); ?>" /></a></td>
                    </tr>
                </table>
                <span class="form-text">(Tamanho ideal: 100x100 px)</span>
            </div><br>

            <!-- E-Mail dos Editores *************************************** -->
            <hr><br>
            <div class="mb-3">
                <label for="portal_input_2" class="form-label">
                    <h5>E-Mails dos Editores</h5>
                </label>
                <?php
                $emails_array = get_option('portal_input_2', []);
                $emails_str = is_array($emails_array) ? implode(', ', $emails_array) : '';
                ?>
                <textarea id="portal_input_2" name="portal_input_2"
                    class="form-control"><?php echo esc_attr($emails_str); ?></textarea>
                <small class="form-text text-muted">(Separe com vírgulas)</small>
            </div><br>


            <!-- E-Mails Convidados *************************************** -->
            <?php /*
                      <hr><br>
          <div class="mb-3">
              <label for="portal_input_3" class="form-label"><h5>E-Mails dos Convidados</h5></label>
              <?php
              $emails_array = get_option('portal_input_3', []);
              $emails_str = is_array($emails_array) ? implode(', ', $emails_array) : '';
              ?>
              <textarea id="portal_input_3" name="portal_input_3" class="form-control"><?php echo esc_attr($emails_str); ?></textarea>
              <small class="form-text text-muted">(Separe com vírgulas)</small>
          </div><br>
            */ ?>

            <!-- E-Mail dos Administradores *************************************** -->
            <hr><br>
            <div class="mb-3">
                <label for="portal_input_4" class="form-label">
                    <h5>E-Mails dos Administradores</h5>
                </label>
                <?php
                $emails_array = get_option('portal_input_4', []);
                $emails_str = is_array($emails_array) ? implode(', ', $emails_array) : '';
                ?>
                <textarea id="portal_input_4" name="portal_input_4"
                    class="form-control"><?php echo esc_attr($emails_str); ?></textarea>
                <small class="form-text text-muted">(Separe com vírgulas)</small>
            </div><br>

            <!-- Texto ********************************** -->
            <hr><br>
            <div class="mb-3">
                <label for="portal_input_5" class="form-label">
                    <h5>Texto:</h5>
                </label>
                <?php
                $portal5 = get_option('portal_input_5');
                wp_editor($portal5, 'portal_input_5', array('textarea_name' => 'portal_input_5'));
                ?>


            </div><br>

            <hr>
            <div class="text-center">
                <?php submit_button(); ?>
            </div>
        </form>
    </div>
    <?php
}

// Adiciona submenu na área de administração
function portal_options_page()
{
    add_submenu_page('icode', 'Configurações', 'Configurações', 'edit_posts', 'pagina-inicial', 'portal_page_html', 1);
}
add_action('admin_menu', 'portal_options_page');


//************************ DB Fields

function portal_settings0()
{
    add_option('portal_input_0');
    register_setting('portal_option_grupo', 'portal_input_0');
}
add_action('admin_init', 'portal_settings0');

function portal_settings1()
{
    add_option('portal_input_1');
    register_setting('portal_option_grupo', 'portal_input_1');
}
add_action('admin_init', 'portal_settings1');

function portal_settings2()
{
    add_option('portal_input_2', []);
    register_setting('portal_option_grupo', 'portal_input_2', [
        'type' => 'array',
        'sanitize_callback' => 'portal_sanitize_emails_array',
        'default' => [],
    ]);
}
add_action('admin_init', 'portal_settings2');

function portal_settings3()
{
    add_option('portal_input_3', []);
    register_setting('portal_option_grupo', 'portal_input_3', [
        'type' => 'array',
        'sanitize_callback' => 'portal_sanitize_emails_array',
        'default' => [],
    ]);
}
add_action('admin_init', 'portal_settings3');

function portal_settings4()
{
    add_option('portal_input_4', []);
    register_setting('portal_option_grupo', 'portal_input_4', [
        'type' => 'array',
        'sanitize_callback' => 'portal_sanitize_emails_array',
        'default' => [],
    ]);
}
add_action('admin_init', 'portal_settings4');

function portal_settings5()
{
    add_option('portal_input_5');
    register_setting('portal_option_grupo', 'portal_input_5');
}
add_action('admin_init', 'portal_settings5');

function portal_sanitize_emails_array($input)
{
    if (is_string($input)) {
        $emails = array_map('trim', explode(',', $input));
    } elseif (is_array($input)) {
        $emails = $input;
    } else {
        return [];
    }

    // Valida e-mails
    return array_filter($emails, function ($email) {
        return is_email($email);
    });
}
