<?php

//Arquivo: wp-content/plugins/novoicode/includes/elfinder.php

require_once($_SERVER['DOCUMENT_ROOT'] . '/wp-load.php');

if (!is_user_logged_in()) {
    http_response_code(403);
    exit('Acesso negado');
}

require_once ABSPATH . 'wp-content/plugins/novoicode/includes/elFinder/php/autoload.php';

use elFinder;
use elFinderConnector;
use elFinderVolumeLocalFileSystem;

$current_user = wp_get_current_user();
$user_roles = $current_user->roles;

$is_admin = in_array('administrator', $user_roles);
$is_editor = in_array('editor', $user_roles);
$is_subscriber = in_array('subscriber', $user_roles);

$post_id_raw = $_GET['post_id'] ?? '';
$ano = intval($_GET['ano'] ?? 0);
$tipo = sanitize_text_field($_GET['tipo'] ?? '');

$modo_geral = empty($tipo) && empty($ano) && empty($post_id_raw);
$tipos_permitidos = get_user_meta($current_user->ID, 'membro', true);

$membro_arquivo_privado = get_user_meta($current_user->ID, 'membro_arquivo_privado', true);
$user_membro_arquivo_privado = is_array($membro_arquivo_privado) && !empty($membro_arquivo_privado) ? $membro_arquivo_privado : [];

$wp_upload_dir = wp_upload_dir();
$roots = [];

// MODO GERAL - Exibe diretórios dos tipos
if ($modo_geral) {
    foreach ($tipos_permitidos as $tipo_dir) {
        $tipo_path = trailingslashit($wp_upload_dir['basedir']) . $tipo_dir . '/';
        $tipo_url = trailingslashit($wp_upload_dir['baseurl']) . $tipo_dir . '/';

        if (!is_dir($tipo_path))
            continue;

        $roots[] = [
            'driver' => 'LocalFileSystem',
            'path' => $tipo_path,
            'URL' => $tipo_url,
            'uploadDeny' => ['all'],
            'uploadAllow' => ['application/pdf'],
            'uploadOrder' => ['deny', 'allow'],
            'accessControl' => function ($attr, $path, $data, $volume) use ($modo_geral, $is_admin, $is_editor, $is_subscriber) {
                if (strpos(basename($path), '.') === 0) {
                    return !($attr === 'read' || $attr === 'write');
                }

                // Verifica se é uma pasta "privado"
                if (strpos($path, '/privado') !== false) {
                    $membro_arquivo_privado = get_user_meta(wp_get_current_user()->ID, 'membro_arquivo_privado', true);
                    // Bloqueia acesso total se não tiver permissão
                    if (!$membro_arquivo_privado) {
                        return false;
                    }
                }

                if ($modo_geral) {
                    if ($is_admin) {
                        return null;
                    }
                    if ($is_subscriber || $is_editor) {
                        return $attr === 'read'; // somente leitura
                    }
                }

                return null;
            },
            'attributes' => [
                [
                    'pattern' => '/\.php$/i',
                    'read' => false,
                    'write' => false,
                    'hidden' => true,
                    'locked' => true,
                ]
            ],
        ];
    }
} else {
    // MODO DIRECIONADO
    if (!$ano || !in_array($tipo, $tipos_permitidos)) {
        http_response_code(400);
        exit('Parâmetros inválidos');
    }

    $post_id_str = ($post_id_raw === 'outros') ? 'outros' : intval($post_id_raw);
    if ($post_id_str === 0 && $post_id_raw !== 'outros') {
        http_response_code(400);
        exit('Parâmetros inválidos: post_id');
    }

    $basePath = trailingslashit($wp_upload_dir['basedir']) . "$tipo/$ano/$post_id_str/";
    $baseURL = trailingslashit($wp_upload_dir['baseurl']) . "$tipo/$ano/$post_id_str/";

    if (!is_dir($basePath)) {
        wp_mkdir_p($basePath);
        if (!is_dir($basePath)) {
            http_response_code(500);
            exit("Falha ao criar diretório base: $basePath");
        }
    }

    $subdirs = array_filter(glob($basePath . '*'), 'is_dir');

    foreach ($subdirs as $subdir) {
        $nomePasta = basename($subdir);

        if ($nomePasta === 'privado' && !in_array($tipo, $user_membro_arquivo_privado)) {
            continue;
        }

        $path = trailingslashit($subdir);
        $url = trailingslashit($baseURL . $nomePasta);

        $roots[] = [
            'driver' => 'LocalFileSystem',
            'path' => $path,
            'URL' => $url,
            'uploadDeny' => ['all'],
            'uploadAllow' => ['application/pdf','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
            'uploadOrder' => ['deny', 'allow'],
            'accessControl' => function ($attr, $path, $data, $volume) use ($is_admin, $is_editor) {
                if (strpos(basename($path), '.') === 0) {
                    return !($attr === 'read' || $attr === 'write');
                }

                // Fora do modo geral: editor/admin pode editar, outros só leitura
                if (!$is_admin && !$is_editor) {
                    return $attr === 'read';
                }

                return null;
            },
            'attributes' => [
                [
                    'pattern' => '/\.php$/i',
                    'read' => false,
                    'write' => false,
                    'hidden' => true,
                    'locked' => true,
                ]
            ],
        ];
    }
}

// ===================== PERMISSÕES DE COMANDOS =====================
$disabledCommands = [];

if ($modo_geral) {
    if ($is_admin) {
        $disabledCommands = []; // Total acesso
    } elseif ($is_editor) {
        $disabledCommands = ['mkdir']; 
    } else {
        // assinante (ou outro papel): somente leitura
        $disabledCommands = ['mkdir', 'mkfile', 'paste', 'rm', 'rename', 'upload', 'copy', 'cut'];
    }
} else {
    // fora do modo geral: apenas assinante tem bloqueios
    if (!$is_admin && !$is_editor) {
        $disabledCommands = ['mkdir', 'mkfile', 'paste', 'rm', 'rename', 'upload', 'copy', 'cut'];
    }
}

// ===================== INICIALIZA =====================
$opts = [
    'roots' => $roots,
    'disabled' => $disabledCommands,
];

$connector = new elFinderConnector(new elFinder($opts));
$connector->run();
