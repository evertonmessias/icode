<?php
//Arquivo: wp-content/plugins/novoicode/includes/types/ci.php
function create_custom_post_type_ci()
{
	$labels = [
		'name' => _x('CI', 'post type general name'),
		'singular_name' => _x('CI', 'post type singular name'),
		'add_new' => _x('Adicionar', 'CI'),
		'add_new_item' => __('Adicionar novo post CI'),
		'edit_item' => __('Editar post CI'),
		'new_item' => __('Novo CI'),
		'view_item' => __('Ver CI'),
		'search_items' => __('Buscar CI'),
		'not_found' =>  __('Nada encontrado'),
		'not_found_in_trash' => __('Nada na lixeira'),
		'parent_item_colon' => ''
	];
	$args = [
		'labels'				=> $labels,
		'supports'              => ['title', 'editor','revisions'],
		'hierarchical'          => false,
        'taxonomies'            => ['category'],
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => false,
		'query_var' 			=> true,
		'menu_position'         => 0,
		'show_in_admin_bar'     => true,
		'rewrite'               => ['slug' => 'ci/%category%','with_front' => false],
		'show_in_nav_menus'     => true,
		'can_export'			=> true,
		'menu_icon'             => 'dashicons-groups',
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'     	=> ['post', 'ci'],
		'map_meta_cap'        => true,
	];
	register_post_type('ci', $args);
}
add_action('init', 'create_custom_post_type_ci');

// Submenu no admin
function type_ci()
{
	add_submenu_page('icode', 'ci', 'CI', 'edit_posts', 'edit.php?post_type=ci');
}
add_action('admin_menu', 'type_ci');

// Permissões
function role_caps_ci()
{
	$roles = array('editor', 'administrator');
	foreach ($roles as $the_role) {
		$role = get_role($the_role);
		if ($role) {
			$role->add_cap('read');
			$role->add_cap('read_ci');
			$role->add_cap('read_private_ci');
			$role->add_cap('edit_ci');
			$role->add_cap('edit_others_ci');
			$role->add_cap('edit_published_ci');
			$role->add_cap('publish_ci');
			$role->add_cap('delete_others_ci');
			$role->add_cap('delete_private_ci');
			$role->add_cap('delete_published_ci');
		}
	}
}
add_action('admin_init', 'role_caps_ci', 999);

//******************************************** POST META ci **************************************************** */

// Privado? ******************************************
function field_box_ci_privado()
{
	add_meta_box('ci_privado_id', 'Reunião Privada', 'field_ci_privado', 'ci', 'side');
}
add_action('add_meta_boxes', 'field_box_ci_privado');

function field_ci_privado($post)
{
	$value = get_post_meta($post->ID, 'ci_privado', true);
	?>
	<label>
		<input type="checkbox" name='ci_privado' value="1" <?php checked($value, '1'); ?>>
		Marcar como reunião privada
	</label>
	<?php
}

// Data **********************************************

function field_box_ci_date()
{
    add_meta_box('ci_date_id', 'Data da Reunião', 'field_ci_date', 'ci', 'advanced');
}
add_action('add_meta_boxes', 'field_box_ci_date');

function field_ci_date($post)
{
    $value = get_post_meta($post->ID, 'ci_date', true);
?>
    <i id="scrollToTop" class='bx bxs-up-arrow-square'></i>
    <input type="datetime-local" name="ci_date" value="<?php echo $value; ?>">
<?php
}

// Membros **********************************************

function field_box_ci_member()
{
        add_meta_box('ci_member_id', 'Membros <small>( preenchimento automático via Intranet )&emsp;</small>', 'field_ci_member', 'ci', 'advanced');
}
add_action('add_meta_boxes', 'field_box_ci_member');

function field_ci_member($post)
{
    $site = 'ci';
    if (get_post_meta($post->ID, 'ci_member', true) == "") {
        $value = do_shortcode('[icapi tipo="composicao_' . $site . '" saida="html/?modo=short"]');
    } else {
        $value = get_post_meta($post->ID, 'ci_member', true);
    }

    $args = array(
        //'textarea_rows' => 20,
        'textarea_name' => 'ci_member',
        'media_buttons' => false,
        'quicktags'     => false,
        'tinymce'       => array(
            'toolbar2' => FALSE,
            'media_buttons' => false,
        ),
    );

    wp_editor($value, 'field_ci_member_id', $args);
?>

<?php
}


//* MOVE  ******************************************************************************************* */


// Move all "advanced" metaboxes after title
add_action('edit_form_after_title', function () {
    global $post, $wp_meta_boxes;
    do_meta_boxes(get_current_screen(), 'advanced', $post);
    unset($wp_meta_boxes[get_post_type($post)]['advanced']);
});

// Move all "default" metaboxes after editor
add_action('edit_form_after_editor', function () {
    global $post, $wp_meta_boxes;
    do_meta_boxes(get_current_screen(), 'default', $post);
    unset($wp_meta_boxes[get_post_type($post)]['default']);
});


/* SAVE ALL ******************************************************************************************* */

add_action('save_post', 'save_postmeta_ci');

function save_postmeta_ci($post_id)
{
	// Impede execução em autosave, revisions ou sem permissão
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
	if (is_int(wp_is_post_revision($post_id))) return;
	if (!current_user_can('edit_post', $post_id)) return;

	// Garante que é do tipo correto
	if (get_post_type($post_id) !== 'ci') return;

	// Salva "privado"
	$privado = isset($_POST['ci_privado']) ? '1' : '0';
	update_post_meta($post_id, 'ci_privado', $privado);

	// Salva data
	if (isset($_POST['ci_date'])) {
		$ci_date = sanitize_text_field($_POST['ci_date']);
		update_post_meta($post_id, 'ci_date', $ci_date);
	}

	// Salva membros
	if (isset($_POST['ci_member'])) {
		$ci_member = wp_kses_post($_POST['ci_member']);
		update_post_meta($post_id, 'ci_member', $ci_member);
	}
}